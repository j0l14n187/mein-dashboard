// Schlagzeilen von tagesschau.de. Der Abruf passiert auf dem Server und wird zwischengespeichert.
// Es werden nur Überschrift, Dachzeile, Anreißer, Zeitpunkt, das Titelbild (mit Bildnachweis) und der Link
// zur Originalseite angezeigt. Bilder lädt der Server über /api/bild nach, dein Browser kontaktiert
// tagesschau.de nicht direkt.
// Die Antwortstruktur ist nicht offiziell dokumentiert, deshalb wird alles defensiv geprüft.

export type NewsImage = {
  /** Adresse unseres eigenen Bild-Proxys (/api/bild?u=…). */
  src: string;
  alt: string;
  credit: string | null;
};

export type NewsItem = {
  id: string;
  title: string;
  topline: string | null;
  teaser: string | null;
  ressort: string | null;
  date: string | null;
  url: string;
  image: NewsImage | null;
};

function str(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

function rec(v: unknown): Record<string, unknown> | null {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
}

/** Nur Bilder von tagesschau.de (inkl. Unterdomains wie images.tagesschau.de) zulassen. */
export function isAllowedImageUrl(raw: string): boolean {
  try {
    const u = new URL(raw);
    return u.protocol === "https:" && (u.hostname === "tagesschau.de" || u.hostname.endsWith(".tagesschau.de"));
  } catch {
    return false;
  }
}

const PREFERRED = ["16x9-960", "16x9-640", "16x9-1280", "16x9-512", "16x9-1920", "16x9-256", "1x1-840", "1x1-432"];

function pickImage(teaserImage: unknown): NewsImage | null {
  const t = rec(teaserImage);
  const variants = rec(t?.imageVariants);
  if (!t || !variants) return null;

  let url: string | null = null;
  for (const key of PREFERRED) {
    const v = str(variants[key]);
    if (v && isAllowedImageUrl(v)) {
      url = v;
      break;
    }
  }
  if (!url) {
    for (const v of Object.values(variants)) {
      const s = str(v);
      if (s && isAllowedImageUrl(s)) {
        url = s;
        break;
      }
    }
  }
  if (!url) return null;

  return {
    src: `/api/bild?u=${encodeURIComponent(url)}`,
    alt: str(t.alttext) ?? str(t.title) ?? "",
    credit: str(t.copyright),
  };
}

export async function getNews(limit = 12): Promise<NewsItem[] | null> {
  try {
    const res = await fetch("https://www.tagesschau.de/api2u/homepage/", {
      next: { revalidate: 300 },
      signal: AbortSignal.timeout(8000),
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;

    const json: unknown = await res.json();
    const news = rec(json)?.news;
    if (!Array.isArray(news)) return null;

    const items: NewsItem[] = [];
    for (const entry of news) {
      const r = rec(entry);
      if (!r) continue;
      const title = str(r.title);
      const url = str(r.shareURL) ?? str(r.detailsweb);
      // Nur Links auf tagesschau.de zulassen.
      if (!title || !url || !url.startsWith("https://www.tagesschau.de/")) continue;

      items.push({
        id: str(r.sophoraId) ?? url,
        title,
        topline: str(r.topline),
        teaser: str(r.firstSentence),
        ressort: str(r.ressort),
        date: str(r.date),
        url,
        image: pickImage(r.teaserImage),
      });
      if (items.length >= limit) break;
    }
    return items;
  } catch {
    return null;
  }
}

const RESSORTS: Record<string, string> = {
  inland: "Inland",
  ausland: "Ausland",
  wirtschaft: "Wirtschaft",
  sport: "Sport",
  wissen: "Wissen",
  investigativ: "Investigativ",
  video: "Video",
  faktenfinder: "Faktenfinder",
  kultur: "Kultur",
};

export function ressortLabel(r: string | null): string | null {
  if (!r) return null;
  return RESSORTS[r.toLowerCase()] ?? r.charAt(0).toUpperCase() + r.slice(1);
}
