// Wetter für Wipperfürth über Open-Meteo (kostenlos für nicht-kommerzielle Nutzung, Lizenz CC BY 4.0).
// Der Abruf passiert auf dem Server. Dein Browser nimmt keinen Kontakt zu Open-Meteo auf.

const LATITUDE = 51.117;
const LONGITUDE = 7.4;

export type WeatherDay = {
  date: string;
  code: number;
  max: number;
  min: number;
  rainChance: number | null;
};

export type Weather = {
  temperature: number;
  feelsLike: number | null;
  humidity: number | null;
  wind: number | null;
  precipitation: number | null;
  code: number;
  days: WeatherDay[];
};

function num(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

export async function getWeather(): Promise<Weather | null> {
  const params = new URLSearchParams({
    latitude: String(LATITUDE),
    longitude: String(LONGITUDE),
    current:
      "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
    timezone: "Europe/Berlin",
    forecast_days: "4",
  });

  try {
    const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`, {
      next: { revalidate: 600 },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;

    const json = (await res.json()) as {
      current?: Record<string, unknown>;
      daily?: Record<string, unknown>;
    };

    const c = json.current;
    const temperature = num(c?.temperature_2m);
    const code = num(c?.weather_code);
    if (!c || temperature === null || code === null) return null;

    const d = json.daily ?? {};
    const dates = Array.isArray(d.time) ? d.time : [];
    const codes = Array.isArray(d.weather_code) ? d.weather_code : [];
    const maxs = Array.isArray(d.temperature_2m_max) ? d.temperature_2m_max : [];
    const mins = Array.isArray(d.temperature_2m_min) ? d.temperature_2m_min : [];
    const rains = Array.isArray(d.precipitation_probability_max) ? d.precipitation_probability_max : [];

    const days: WeatherDay[] = [];
    dates.forEach((date: unknown, i: number) => {
      const dc = num(codes[i]);
      const mx = num(maxs[i]);
      const mn = num(mins[i]);
      if (typeof date === "string" && dc !== null && mx !== null && mn !== null) {
        days.push({ date, code: dc, max: mx, min: mn, rainChance: num(rains[i]) });
      }
    });

    return {
      temperature,
      feelsLike: num(c.apparent_temperature),
      humidity: num(c.relative_humidity_2m),
      wind: num(c.wind_speed_10m),
      precipitation: num(c.precipitation),
      code,
      days,
    };
  } catch {
    return null;
  }
}

export function describeWeather(code: number): string {
  if (code === 0) return "Klar";
  if (code === 1) return "Überwiegend klar";
  if (code === 2) return "Teils bewölkt";
  if (code === 3) return "Bedeckt";
  if (code === 45 || code === 48) return "Nebel";
  if (code >= 51 && code <= 55) return "Nieselregen";
  if (code === 56 || code === 57) return "Gefrierender Nieselregen";
  if (code >= 61 && code <= 65) return "Regen";
  if (code === 66 || code === 67) return "Gefrierender Regen";
  if (code >= 71 && code <= 75) return "Schneefall";
  if (code === 77) return "Schneegriesel";
  if (code >= 80 && code <= 82) return "Regenschauer";
  if (code === 85 || code === 86) return "Schneeschauer";
  if (code === 95) return "Gewitter";
  if (code === 96 || code === 99) return "Gewitter mit Hagel";
  return "Unbekannt";
}

export type WeatherKind = "clear" | "partly" | "cloudy" | "fog" | "rain" | "snow" | "storm";

/** Gruppiert die Wettercodes für die Symbole. */
export function weatherKind(code: number): WeatherKind {
  if (code === 0 || code === 1) return "clear";
  if (code === 2) return "partly";
  if (code === 3) return "cloudy";
  if (code === 45 || code === 48) return "fog";
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "rain";
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return "snow";
  if (code >= 95) return "storm";
  return "cloudy";
}
