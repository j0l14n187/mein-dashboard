// Microsoft-Anmeldung (OAuth 2.0 Authorization Code + PKCE) und Microsoft Graph.
// Alles läuft auf dem Server. Das Client-Secret und die Token erreichen nie den Browser.
// Es werden nur lesende Berechtigungen angefragt.

import type { CalEvent } from "./ical";
import { getSession, sessionSecret, updateSession } from "./session";

export const MS_SCOPES = "offline_access User.Read Chat.Read Calendars.Read Files.Read";

export type MsConfig = {
  clientId: string;
  clientSecret: string;
  tenant: string;
  redirectUri: string;
};

export function msConfig(): MsConfig | null {
  const clientId = process.env.MICROSOFT_CLIENT_ID?.trim();
  const clientSecret = process.env.MICROSOFT_CLIENT_SECRET?.trim();
  if (!clientId || !clientSecret || !sessionSecret()) return null;
  return {
    clientId,
    clientSecret,
    tenant: process.env.MICROSOFT_TENANT_ID?.trim() || "organizations",
    redirectUri:
      process.env.MICROSOFT_REDIRECT_URI?.trim() || "http://localhost:3000/api/auth/microsoft/callback",
  };
}

/** Adresse, unter der der Browser das Dashboard sieht (wichtig hinter Proxys und in Codespaces). */
export function appOrigin(req: Request): string {
  const c = msConfig();
  if (c) {
    try {
      return new URL(c.redirectUri).origin;
    } catch {
      // fällt auf die Anfrage-Adresse zurück
    }
  }
  return new URL(req.url).origin;
}

const authority = (c: MsConfig) => `https://login.microsoftonline.com/${encodeURIComponent(c.tenant)}/oauth2/v2.0`;

export function buildAuthUrl(c: MsConfig, state: string, challenge: string): string {
  const p = new URLSearchParams({
    client_id: c.clientId,
    response_type: "code",
    redirect_uri: c.redirectUri,
    response_mode: "query",
    scope: MS_SCOPES,
    state,
    code_challenge: challenge,
    code_challenge_method: "S256",
    prompt: "select_account",
  });
  return `${authority(c)}/authorize?${p.toString()}`;
}

export type TokenSet = { accessToken: string; refreshToken: string | null; expiresAt: number };

async function tokenRequest(c: MsConfig, body: Record<string, string>): Promise<TokenSet | null> {
  try {
    const res = await fetch(`${authority(c)}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: c.clientId, client_secret: c.clientSecret, ...body }),
      signal: AbortSignal.timeout(10_000),
      cache: "no-store",
    });
    if (!res.ok) return null;
    const j = (await res.json()) as { access_token?: string; refresh_token?: string; expires_in?: number };
    if (!j.access_token) return null;
    return {
      accessToken: j.access_token,
      refreshToken: j.refresh_token ?? null,
      expiresAt: Date.now() + (j.expires_in ?? 3600) * 1000,
    };
  } catch {
    return null;
  }
}

export function exchangeCode(c: MsConfig, code: string, verifier: string) {
  return tokenRequest(c, {
    grant_type: "authorization_code",
    code,
    redirect_uri: c.redirectUri,
    code_verifier: verifier,
    scope: MS_SCOPES,
  });
}

// ---------- Graph ----------

export type GraphResult<T> = { ok: true; data: T } | { ok: false; reason: "login" | "forbidden" | "error" };

/** Gültiges Zugriffstoken der aktuellen Sitzung (wird bei Bedarf erneuert). */
async function accessToken(): Promise<string | null> {
  const s = await getSession();
  if (!s) return null;
  if (s.data.expiresAt - Date.now() > 60_000) return s.data.accessToken;

  const c = msConfig();
  if (!c || !s.data.refreshToken) return null;
  const t = await tokenRequest(c, {
    grant_type: "refresh_token",
    refresh_token: s.data.refreshToken,
    scope: MS_SCOPES,
  });
  if (!t) return null;
  updateSession(s.id, {
    accessToken: t.accessToken,
    refreshToken: t.refreshToken ?? s.data.refreshToken,
    expiresAt: t.expiresAt,
  });
  return t.accessToken;
}

export async function hasMicrosoftSession(): Promise<boolean> {
  return (await getSession()) !== null;
}

export async function graph<T>(path: string, headers: Record<string, string> = {}): Promise<GraphResult<T>> {
  const token = await accessToken();
  if (!token) return { ok: false, reason: "login" };
  try {
    const res = await fetch(`https://graph.microsoft.com/v1.0${path}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json", ...headers },
      signal: AbortSignal.timeout(10_000),
      cache: "no-store",
    });
    if (res.status === 401) return { ok: false, reason: "login" };
    if (res.status === 403) return { ok: false, reason: "forbidden" };
    if (!res.ok) return { ok: false, reason: "error" };
    return { ok: true, data: (await res.json()) as T };
  } catch {
    return { ok: false, reason: "error" };
  }
}

function str(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v : null;
}

function rec(v: unknown): Record<string, unknown> | null {
  return typeof v === "object" && v !== null ? (v as Record<string, unknown>) : null;
}

function list(v: unknown): unknown[] {
  return Array.isArray(v) ? v : [];
}

// ---------- Profil ----------

export type MsProfile = { id: string; name: string };

export async function getProfile(): Promise<GraphResult<MsProfile>> {
  const r = await graph<Record<string, unknown>>("/me?$select=id,displayName");
  if (!r.ok) return r;
  return { ok: true, data: { id: str(r.data.id) ?? "", name: str(r.data.displayName) ?? "Du" } };
}

// ---------- Teams ----------

export type TeamsChat = {
  id: string;
  title: string;
  kind: "oneOnOne" | "group" | "meeting" | "other";
  preview: string | null;
  previewFrom: string | null;
  at: Date | null;
};

export type TeamsMessage = {
  id: string;
  from: string;
  text: string;
  at: Date | null;
  mine: boolean;
};

const ENTITIES: Record<string, string> = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'", "&nbsp;": " " };

/** Teams liefert Nachrichten oft als HTML. Hier wird daraus einfacher Text. */
export function htmlToText(html: string): string {
  return html
    .replace(/<img[^>]*>/gi, "[Bild] ")
    .replace(/<attachment[^>]*>.*?<\/attachment>/gis, "")
    .replace(/<br\s*\/?>|<\/p>|<\/div>|<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&(?:amp|lt|gt|quot|#39|nbsp);/g, (m) => ENTITIES[m] ?? m)
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function date(v: unknown): Date | null {
  const s = str(v);
  if (!s) return null;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

export async function getChats(myId: string): Promise<GraphResult<TeamsChat[]>> {
  const r = await graph<{ value?: unknown }>(
    "/me/chats?$expand=members,lastMessagePreview&$top=25&$orderby=lastMessagePreview/createdDateTime%20desc",
  );
  if (!r.ok) return r;

  const chats: TeamsChat[] = [];
  for (const item of list(r.data.value)) {
    const c = rec(item);
    const id = str(c?.id);
    if (!c || !id) continue;

    const members = list(c.members)
      .map((m) => rec(m))
      .filter((m): m is Record<string, unknown> => m !== null);
    const others = members.filter((m) => str(m.userId) !== myId).map((m) => str(m.displayName)).filter(Boolean) as string[];

    const type = str(c.chatType);
    const kind: TeamsChat["kind"] =
      type === "oneOnOne" ? "oneOnOne" : type === "group" ? "group" : type === "meeting" ? "meeting" : "other";
    const topic = str(c.topic);
    const title =
      topic ?? (others.length ? others.slice(0, 3).join(", ") + (others.length > 3 ? " u. a." : "") : "Chat");

    const lm = rec(c.lastMessagePreview);
    const body = rec(lm?.body);
    const previewRaw = str(body?.content);
    const preview = previewRaw ? htmlToText(previewRaw).replace(/\s+/g, " ").slice(0, 140) : null;
    const from = str(rec(rec(lm?.from)?.user)?.displayName);

    chats.push({
      id,
      title,
      kind,
      preview: preview || null,
      previewFrom: from,
      at: date(lm?.createdDateTime) ?? date(c.lastUpdatedDateTime),
    });
  }
  return { ok: true, data: chats };
}

const CHAT_ID = /^[A-Za-z0-9:@._;=-]{5,200}$/;

export async function getMessages(chatId: string, myId: string): Promise<GraphResult<TeamsMessage[]>> {
  if (!CHAT_ID.test(chatId)) return { ok: false, reason: "error" };
  const r = await graph<{ value?: unknown }>(`/me/chats/${encodeURIComponent(chatId)}/messages?$top=30`);
  if (!r.ok) return r;

  const out: TeamsMessage[] = [];
  for (const item of list(r.data.value)) {
    const m = rec(item);
    const id = str(m?.id);
    if (!m || !id || str(m.messageType) !== "message" || m.deletedDateTime) continue;
    const body = rec(m.body);
    const raw = str(body?.content) ?? "";
    const text = str(body?.contentType) === "html" ? htmlToText(raw) : raw.trim();
    if (!text) continue;
    const user = rec(rec(m.from)?.user);
    out.push({
      id,
      from: str(user?.displayName) ?? "Unbekannt",
      text: text.slice(0, 2000),
      at: date(m.createdDateTime),
      mine: str(user?.id) === myId,
    });
  }
  // Die API liefert die neuesten zuerst. Für den Chatverlauf unten die neuesten.
  return { ok: true, data: out.reverse() };
}

// ---------- Kalender ----------

export async function getGraphEvents(from: Date, to: Date): Promise<GraphResult<CalEvent[]>> {
  const q = new URLSearchParams({
    startDateTime: from.toISOString(),
    endDateTime: to.toISOString(),
    $orderby: "start/dateTime",
    $top: "60",
    $select: "id,subject,start,end,isAllDay,location,isCancelled",
  });
  const r = await graph<{ value?: unknown }>(`/me/calendarView?${q.toString()}`, {
    Prefer: 'outlook.timezone="UTC"',
  });
  if (!r.ok) return r;

  const out: CalEvent[] = [];
  for (const item of list(r.data.value)) {
    const e = rec(item);
    if (!e || e.isCancelled === true) continue;
    const s = str(rec(e.start)?.dateTime);
    const en = str(rec(e.end)?.dateTime);
    if (!s || !en) continue;
    const start = new Date(`${s.split(".")[0]}Z`);
    const end = new Date(`${en.split(".")[0]}Z`);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) continue;
    out.push({
      id: str(e.id) ?? `${s}`,
      title: str(e.subject) ?? "Ohne Titel",
      start,
      end,
      allDay: e.isAllDay === true,
      location: str(rec(e.location)?.displayName),
      description: null,
    });
  }
  return { ok: true, data: out };
}

// ---------- Dateien ----------

export type DriveFile = {
  id: string;
  name: string;
  url: string | null;
  modified: Date | null;
  size: number | null;
  isFolder: boolean;
};

export async function getRecentFiles(): Promise<GraphResult<DriveFile[]>> {
  const r = await graph<{ value?: unknown }>("/me/drive/recent?$top=25");
  if (!r.ok) return r;

  const out: DriveFile[] = [];
  for (const item of list(r.data.value)) {
    const f = rec(item);
    const name = str(f?.name);
    const id = str(f?.id);
    if (!f || !name || !id) continue;
    const url = str(f.webUrl);
    out.push({
      id,
      name,
      // Nur https-Links zulassen.
      url: url && url.startsWith("https://") ? url : null,
      modified: date(f.lastModifiedDateTime),
      size: typeof f.size === "number" ? f.size : null,
      isFolder: rec(f.folder) !== null || rec(rec(f.remoteItem)?.folder) !== null,
    });
  }
  return { ok: true, data: out };
}
