import type { IconName } from "@/components/Icon";

export type Integration = {
  slug: string;
  title: string;
  subtitle: string;
  icon: IconName;
  color: string;
  summary: string;
  steps: string[];
  scopes: string[];
  notes: string[];
};

const MICROSOFT_STEPS = [
  "Im Microsoft Entra Admin Center unter „App-Registrierungen“ eine neue Registrierung anlegen (Konten nur in diesem Organisationsverzeichnis).",
  "Als Redirect-URI (Typ „Web“) eintragen: http://localhost:3000/api/auth/microsoft/callback. Im Codespace die Adresse des Codespace verwenden und dieselbe in MICROSOFT_REDIRECT_URI setzen.",
  "Unter „Zertifikate & Geheimnisse“ ein neues Client-Secret erzeugen und den Wert sofort kopieren.",
  "Unter „API-Berechtigungen“ diese delegierten Berechtigungen von Microsoft Graph hinzufügen: User.Read, Chat.Read, Calendars.Read, Files.Read.",
  "In .env.local eintragen: MICROSOFT_CLIENT_ID, MICROSOFT_CLIENT_SECRET und SESSION_SECRET (zufälliger Text, mindestens 16 Zeichen, z. B. mit: openssl rand -base64 32). Optional MICROSOFT_TENANT_ID.",
  "Das Dashboard neu starten und oben „Mit Microsoft anmelden“ wählen.",
];

export const integrations: Integration[] = [
  {
    slug: "teams",
    title: "Microsoft Teams",
    subtitle: "Chats und Nachrichten",
    icon: "chat",
    color: "#8f7cff",
    summary:
      "Deine Teams-Chats direkt im Dashboard: Liste der Unterhaltungen und die letzten Nachrichten, nur lesend.",
    steps: MICROSOFT_STEPS,
    scopes: ["User.Read", "Chat.Read", "offline_access"],
    notes: [
      "Ob du diese Berechtigungen selbst freigeben darfst, entscheidet die IT deiner Schule.",
      "Chats enthalten Daten anderer Personen. Frage vorher bei der Schule nach, ob die Nutzung erlaubt ist.",
      "Das Client-Secret und alle Token bleiben auf dem Server. Der Browser bekommt nur eine zufällige Sitzungs-ID.",
      "Nach einem Neustart des Dashboards musst du dich neu anmelden.",
    ],
  },
  {
    slug: "untis",
    title: "WebUntis",
    subtitle: "Stundenplan",
    icon: "clock",
    color: "#ffb02e",
    summary:
      "Dein Stundenplan der nächsten 7 Tage mit Entfall und Änderungen, dazu optional die WebUntis-Seite als Live-Ansicht.",
    steps: [
      "Variante A (empfohlen, ohne Passwort): In WebUntis einen iCal-Link / Kalender-Abo für deinen Stundenplan erzeugen, falls deine Schule das freigibt. Den Link in .env.local als UNTIS_ICAL_URL eintragen.",
      "Variante B: Die Zugangsdaten in .env.local eintragen: UNTIS_SERVER (z. B. mese.webuntis.com), UNTIS_SCHOOL (Schulname wie in der WebUntis-Adresse), UNTIS_USER und UNTIS_PASSWORD.",
      "Optional UNTIS_URL setzen (Adresse deiner WebUntis-Seite) für die Live-Ansicht und den „Öffnen“-Knopf.",
      "Das Dashboard neu starten.",
    ],
    scopes: [],
    notes: [
      "Nutze nur Zugänge, die deine Schule ausdrücklich erlaubt.",
      "Ein iCal-Link enthält einen geheimen Schlüssel und das Passwort steht im Klartext in .env.local. Gib beides nie weiter und checke .env.local nie in Git ein.",
      "Das Dashboard liest nur und verändert nichts.",
    ],
  },
  {
    slug: "iserv",
    title: "IServ",
    subtitle: "Schulplattform",
    icon: "school",
    color: "#38bdf8",
    summary:
      "Dein IServ-Kalender im Dashboard (per iCal-Link) und IServ selbst als Live-Ansicht, sofern deine Schule das Einbetten erlaubt.",
    steps: [
      "Die Adresse deiner IServ-Seite in .env.local als ISERV_URL eintragen, zum Beispiel https://deineschule.de",
      "Optional in IServ unter Kalender den Kalender als iCal-Link abonnieren bzw. exportieren und den Link als ISERV_ICAL_URL eintragen.",
      "Das Dashboard neu starten (Strg + C, dann npm run dev).",
    ],
    scopes: [],
    notes: [
      "Zugangsdaten gibst du nur direkt bei IServ ein, nie im Dashboard.",
      "Die meisten IServ-Seiten verbieten das Einbetten. Das Dashboard prüft das und zeigt dann einen Hinweis statt eines leeren Rahmens.",
      "Der iCal-Link enthält einen geheimen Schlüssel. Gib ihn nicht weiter.",
    ],
  },
  {
    slug: "kalender",
    title: "Kalender",
    subtitle: "Termine und Fristen",
    icon: "calendar",
    color: "#fb7185",
    summary:
      "Deine Termine der nächsten 14 Tage, wahlweise aus einem iCal-Link oder aus Microsoft 365.",
    steps: [
      "Variante A: Einen iCal-Link deines Kalenders (Outlook, Google, iCloud …) in .env.local als CALENDAR_ICAL_URL eintragen.",
      "Variante B: Die Microsoft-Anmeldung wie bei Teams einrichten (Berechtigung Calendars.Read). Der iCal-Link hat Vorrang, wenn beides gesetzt ist.",
      "Das Dashboard neu starten.",
    ],
    scopes: ["Calendars.Read"],
    notes: [
      "Es werden keine Termine verändert. Die Anbindung ist nur lesend.",
      "Ein iCal-Link enthält einen geheimen Schlüssel. Gib ihn nicht weiter.",
    ],
  },
  {
    slug: "dateien",
    title: "Dateien",
    subtitle: "Dokumente und Notizen",
    icon: "folder",
    color: "#34d399",
    summary:
      "Deine zuletzt verwendeten OneDrive-Dateien mit Namen, Datum und Link, über dieselbe Microsoft-Anmeldung wie Teams.",
    steps: [
      "Die Microsoft-Anmeldung wie bei Teams einrichten (Berechtigung Files.Read).",
      "Das Dashboard neu starten und oben „Mit Microsoft anmelden“ wählen.",
    ],
    scopes: ["Files.Read"],
    notes: [
      "Es werden nur Dateinamen und Links angezeigt, keine Inhalte. Auf dem Server wird nichts gespeichert.",
    ],
  },
  {
    slug: "chess",
    title: "Chess.com",
    subtitle: "Schach-Statistiken",
    icon: "chess",
    color: "#a3e635",
    summary:
      "Die öffentlichen Statistiken deines Chess.com-Kontos: Wertungen, Bilanz und Aufgaben.",
    steps: [
      "Deinen Chess.com-Nutzernamen in der Datei .env.local als CHESSCOM_USERNAME eintragen.",
      "Das Dashboard neu starten (Strg + C, dann npm run dev).",
      "Die Daten kommen aus der öffentlichen Schnittstelle von Chess.com.",
    ],
    scopes: [],
    notes: [
      "Es werden nur öffentliche Profildaten gelesen. Ein Passwort ist nicht nötig.",
      "Ist dein Profil gesperrt oder der Name falsch, werden keine Daten angezeigt.",
    ],
  },
];

export function getIntegration(slug: string): Integration | undefined {
  return integrations.find((i) => i.slug === slug);
}
