/**
 * Zentrale Stelle für alle rechtlichen Angaben.
 *
 * WICHTIG: Ersetze jeden Eintrag mit "[PLATZHALTER" durch deine echten Angaben,
 * bevor die Seite öffentlich im Internet erreichbar ist.
 * Mit `npm run check:legal` prüfst du, ob noch Platzhalter übrig sind.
 *
 * Läuft das Dashboard nur lokal auf deinem Rechner (localhost) und ist niemand
 * sonst erreichbar, brauchst du kein Impressum. Sobald es öffentlich online ist,
 * solltest du alles ausfüllen.
 */
export const legal = {
  name: "[PLATZHALTER: Vor- und Nachname]",
  street: "[PLATZHALTER: Straße und Hausnummer]",
  city: "[PLATZHALTER: PLZ und Ort]",
  country: "Deutschland",
  email: "[PLATZHALTER: E-Mail-Adresse]",
  phone: "[PLATZHALTER: Telefonnummer, optional]",

  // Hosting
  hostName: "[PLATZHALTER: Name und Anschrift des Hosting-Anbieters]",
  logRetention: "[PLATZHALTER: Speicherdauer der Server-Logs, z. B. 7 Tage]",

  // Zuständige Datenschutz-Aufsichtsbehörde (Landesdatenschutzbeauftragte/r deines Bundeslandes)
  authority: "[PLATZHALTER: Datenschutz-Aufsichtsbehörde deines Bundeslandes]",

  updated: "Oktober 2026",
} as const;
