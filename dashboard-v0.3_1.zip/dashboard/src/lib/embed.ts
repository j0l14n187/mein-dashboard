// Prüft auf dem Server, ob eine Seite sich überhaupt in einem Rahmen (iframe) anzeigen lässt.
// Viele Dienste (Teams, IServ, WebUntis) verbieten das per Header. Dann zeigen wir einen Hinweis
// statt eines leeren Rahmens.

export async function canEmbed(rawUrl: string): Promise<boolean | null> {
  try {
    const res = await fetch(rawUrl, {
      method: "GET",
      redirect: "follow",
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(6000),
      headers: { Accept: "text/html" },
    });
    // Nur die Header zählen, der Inhalt wird nicht gelesen.
    res.body?.cancel().catch(() => undefined);

    const xfo = res.headers.get("x-frame-options")?.toLowerCase() ?? "";
    if (xfo.includes("deny") || xfo.includes("sameorigin")) return false;

    const csp = res.headers.get("content-security-policy") ?? "";
    const fa = /frame-ancestors\s+([^;]+)/i.exec(csp)?.[1]?.trim().toLowerCase();
    if (fa && (fa === "'none'" || fa === "'self'")) return false;

    return true;
  } catch {
    return null; // unbekannt, der Nutzer kann es trotzdem versuchen
  }
}
