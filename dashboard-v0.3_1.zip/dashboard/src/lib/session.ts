// Serverseitige Sitzungen für die Microsoft-Anmeldung.
// Die Zugriffstoken liegen nur im Arbeitsspeicher des Servers. Im Browser liegt lediglich eine
// zufällige, signierte Sitzungs-ID in einem httpOnly-Cookie. Nach einem Neustart des Servers
// muss man sich neu anmelden.

import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const SESSION_COOKIE = "dashboard_sid";
export const OAUTH_COOKIE = "dashboard_oauth";
const MAX_AGE_MS = 8 * 60 * 60 * 1000;

export type Session = {
  accessToken: string;
  refreshToken: string | null;
  expiresAt: number;
  userId: string | null;
  name: string | null;
  createdAt: number;
};

const g = globalThis as unknown as { __dashboardSessions?: Map<string, Session> };
const store: Map<string, Session> = (g.__dashboardSessions ??= new Map());

export function sessionSecret(): string | null {
  const s = process.env.SESSION_SECRET?.trim();
  return s && s.length >= 16 ? s : null;
}

function sign(id: string, secret: string): string {
  return createHmac("sha256", secret).update(id).digest("base64url");
}

function purge() {
  const now = Date.now();
  for (const [id, s] of store) if (now - s.createdAt > MAX_AGE_MS) store.delete(id);
}

/** Legt eine Sitzung an und gibt den Cookie-Wert zurück. */
export function createSession(data: Omit<Session, "createdAt">): string | null {
  const secret = sessionSecret();
  if (!secret) return null;
  purge();
  const id = randomBytes(32).toString("base64url");
  store.set(id, { ...data, createdAt: Date.now() });
  return `${id}.${sign(id, secret)}`;
}

function idFromCookie(value: string | undefined): string | null {
  const secret = sessionSecret();
  if (!secret || !value) return null;
  const [id, sig] = value.split(".");
  if (!id || !sig) return null;
  const expected = sign(id, secret);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return id;
}

export async function getSession(): Promise<{ id: string; data: Session } | null> {
  const jar = await cookies();
  const id = idFromCookie(jar.get(SESSION_COOKIE)?.value);
  if (!id) return null;
  const data = store.get(id);
  if (!data) return null;
  if (Date.now() - data.createdAt > MAX_AGE_MS) {
    store.delete(id);
    return null;
  }
  return { id, data };
}

export function updateSession(id: string, patch: Partial<Session>) {
  const cur = store.get(id);
  if (cur) store.set(id, { ...cur, ...patch });
}

export function deleteSessionByCookie(value: string | undefined) {
  const id = idFromCookie(value);
  if (id) store.delete(id);
}

export function cookieOptions(req: Request, maxAgeSeconds: number) {
  const proto = req.headers.get("x-forwarded-proto") ?? new URL(req.url).protocol.replace(":", "");
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: proto === "https",
    path: "/",
    maxAge: maxAgeSeconds,
  };
}
