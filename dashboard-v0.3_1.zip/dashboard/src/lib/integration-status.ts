// Nur auf dem Server verwenden: liest Umgebungsvariablen aus .env.local und den Anmeldestatus.

import { calendarIcalUrl, iservIcalUrl } from "./calendar";
import { hasMicrosoftSession, msConfig } from "./microsoft";
import { untisConfig } from "./untis";

export function chessUsername(): string | null {
  const raw = process.env.CHESSCOM_USERNAME?.trim();
  if (!raw) return null;
  return /^[A-Za-z0-9_-]{3,25}$/.test(raw) ? raw : null;
}

export function httpsUrl(raw: string | undefined): string | null {
  if (!raw) return null;
  try {
    const url = new URL(raw.trim());
    return url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

export function iservUrl(): string | null {
  return httpsUrl(process.env.ISERV_URL);
}

/** Adresse der WebUntis-Seite (für „Öffnen“ und die Live-Ansicht). */
export function untisUrl(): string | null {
  const explicit = httpsUrl(process.env.UNTIS_URL);
  if (explicit) return explicit;
  const server = process.env.UNTIS_SERVER?.trim().replace(/^https?:\/\//i, "").replace(/\/.*$/, "");
  return server ? httpsUrl(`https://${server}/WebUntis/`) : null;
}

export type Status = { label: string; connected: boolean };

const off: Status = { label: "Nicht eingerichtet", connected: false };

export async function getStatuses(): Promise<Record<string, Status>> {
  const ms = msConfig();
  const signedIn = ms ? await hasMicrosoftSession() : false;
  const msStatus: Status = !ms
    ? off
    : signedIn
      ? { label: "Verbunden", connected: true }
      : { label: "Anmeldung nötig", connected: false };

  const untis = untisConfig();
  const calendar = calendarIcalUrl();

  return {
    teams: msStatus,
    dateien: msStatus,
    kalender: calendar ? { label: "Kalender-Link aktiv", connected: true } : msStatus,
    untis: untis ? { label: "Stundenplan aktiv", connected: true } : untisUrl() ? { label: "Nur Link", connected: false } : off,
    iserv: iservIcalUrl()
      ? { label: "Kalender aktiv", connected: true }
      : iservUrl()
        ? { label: "Link eingerichtet", connected: true }
        : off,
    chess: chessUsername() ? { label: "Öffentliche Daten", connected: true } : off,
  };
}

export function openLinkFor(slug: string): { url: string; label: string } | null {
  switch (slug) {
    case "teams":
      return { url: "https://teams.microsoft.com", label: "Teams in neuem Tab öffnen" };
    case "untis": {
      const url = untisUrl();
      return { url: url ?? "https://webuntis.com", label: "WebUntis in neuem Tab öffnen" };
    }
    case "iserv": {
      const url = iservUrl();
      return url ? { url, label: "IServ in neuem Tab öffnen" } : null;
    }
    case "kalender":
      return { url: "https://outlook.office.com/calendar", label: "Outlook-Kalender öffnen" };
    case "dateien":
      return { url: "https://www.office.com/launch/onedrive", label: "OneDrive öffnen" };
    case "chess": {
      const user = chessUsername();
      return {
        url: user ? `https://www.chess.com/member/${encodeURIComponent(user)}` : "https://www.chess.com",
        label: "Chess.com in neuem Tab öffnen",
      };
    }
    default:
      return null;
  }
}

/** Seiten, die sich (falls erlaubt) als Live-Ansicht einbetten lassen. */
export function embedUrlFor(slug: string): string | null {
  if (slug === "iserv") return iservUrl();
  if (slug === "untis") return untisUrl();
  return null;
}
