// Kleiner iCal-Parser (RFC 5545) für Kalender-Abos, z. B. von WebUntis, IServ, Outlook oder Google.
// Unterstützt: Zeitzonen (TZID), ganztägige Termine, einfache Wiederholungen (RRULE: täglich, wöchentlich,
// monatlich, jährlich mit INTERVAL, COUNT, UNTIL, BYDAY), Ausnahmen (EXDATE) und geänderte Einzeltermine.
// Läuft nur auf dem Server und hat keine Abhängigkeiten.

export type CalEvent = {
  id: string;
  title: string;
  start: Date;
  end: Date;
  allDay: boolean;
  location: string | null;
  description: string | null;
  /** Nur für Stundenpläne: Entfall oder Änderung. */
  status?: "cancelled" | "changed" | null;
  /** Zusatzzeile, z. B. Lehrkraft. */
  note?: string | null;
};

const DEFAULT_TZ = "Europe/Berlin";

// Häufige Windows-Zeitzonennamen, wie sie Outlook verwendet.
const WINDOWS_TZ: Record<string, string> = {
  "W. Europe Standard Time": "Europe/Berlin",
  "Central Europe Standard Time": "Europe/Budapest",
  "Romance Standard Time": "Europe/Paris",
  "GMT Standard Time": "Europe/London",
  "UTC": "UTC",
};

type Prop = { name: string; params: Record<string, string>; value: string };

function unfold(text: string): string[] {
  return text.replace(/\r\n|\r/g, "\n").replace(/\n[ \t]/g, "").split("\n");
}

function parseLine(line: string): Prop | null {
  // Name;PARAM=wert;PARAM2="wert:mit:doppelpunkt":Wert
  let inQuote = false;
  let colon = -1;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') inQuote = !inQuote;
    else if (c === ":" && !inQuote) {
      colon = i;
      break;
    }
  }
  if (colon < 1) return null;
  const head = line.slice(0, colon);
  const value = line.slice(colon + 1);
  const parts: string[] = [];
  let cur = "";
  inQuote = false;
  for (const c of head) {
    if (c === '"') inQuote = !inQuote;
    if (c === ";" && !inQuote) {
      parts.push(cur);
      cur = "";
    } else cur += c;
  }
  parts.push(cur);
  const name = parts[0].toUpperCase();
  const params: Record<string, string> = {};
  for (const p of parts.slice(1)) {
    const eq = p.indexOf("=");
    if (eq > 0) params[p.slice(0, eq).toUpperCase()] = p.slice(eq + 1).replace(/^"|"$/g, "");
  }
  return { name, params, value };
}

function unescapeText(v: string): string {
  return v.replace(/\\([nN])/g, "\n").replace(/\\([,;\\])/g, "$1").trim();
}

// ---------- Zeitzonen ----------

function resolveTz(tz: string | undefined): string {
  if (!tz) return DEFAULT_TZ;
  const mapped = WINDOWS_TZ[tz] ?? tz;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: mapped });
    return mapped;
  } catch {
    return DEFAULT_TZ;
  }
}

const dtfCache = new Map<string, Intl.DateTimeFormat>();
function dtf(tz: string): Intl.DateTimeFormat {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    dtfCache.set(tz, f);
  }
  return f;
}

type Wall = { y: number; mo: number; d: number; h: number; mi: number; s: number };

/** Wanduhr-Zeit einer UTC-Zeit in der Zeitzone. */
export function toWall(ts: number, tz: string): Wall {
  const parts = dtf(tz).formatToParts(new Date(ts));
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? 0);
  return { y: get("year"), mo: get("month"), d: get("day"), h: get("hour") % 24, mi: get("minute"), s: get("second") };
}

function wallAsUtc(w: Wall): number {
  return Date.UTC(w.y, w.mo - 1, w.d, w.h, w.mi, w.s);
}

/** Wanduhr-Zeit einer Zeitzone in einen UTC-Zeitstempel umrechnen (berücksichtigt Sommerzeit). */
export function wallToUtc(w: Wall, tz: string): number {
  if (tz === "UTC") return wallAsUtc(w);
  const guess = wallAsUtc(w);
  let offset = wallAsUtc(toWall(guess, tz)) - guess;
  let result = guess - offset;
  const offset2 = wallAsUtc(toWall(result, tz)) - result;
  if (offset2 !== offset) {
    offset = offset2;
    result = guess - offset;
  }
  return result;
}

type DateVal = { ts: number; allDay: boolean; tz: string };

function parseDate(prop: Prop): DateVal | null {
  const v = prop.value.trim();
  const m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?(Z)?)?$/.exec(v);
  if (!m) return null;
  const [, y, mo, d, h, mi, s, z] = m;
  const allDay = prop.params.VALUE === "DATE" || h === undefined;
  const wall: Wall = { y: +y, mo: +mo, d: +d, h: +(h ?? 0), mi: +(mi ?? 0), s: +(s ?? 0) };
  if (z) return { ts: wallAsUtc(wall), allDay: false, tz: "UTC" };
  const tz = resolveTz(prop.params.TZID);
  return { ts: wallToUtc(wall, tz), allDay, tz };
}

function parseDuration(v: string): number | null {
  const m = /^([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(v.trim());
  if (!m) return null;
  const sign = m[1] === "-" ? -1 : 1;
  const [w, d, h, mi, s] = [m[2], m[3], m[4], m[5], m[6]].map((x) => Number(x ?? 0));
  return sign * (((w * 7 + d) * 24 + h) * 3600 + mi * 60 + s) * 1000;
}

// ---------- Wiederholungen ----------

type Rule = {
  freq: "DAILY" | "WEEKLY" | "MONTHLY" | "YEARLY";
  interval: number;
  count: number | null;
  until: number | null;
  byday: number[]; // 0 = Sonntag … 6 = Samstag
};

const DAYS = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];

function parseRule(value: string): Rule | null {
  const map: Record<string, string> = {};
  for (const part of value.split(";")) {
    const eq = part.indexOf("=");
    if (eq > 0) map[part.slice(0, eq).toUpperCase()] = part.slice(eq + 1);
  }
  const freq = map.FREQ as Rule["freq"];
  if (!["DAILY", "WEEKLY", "MONTHLY", "YEARLY"].includes(freq)) return null;
  let until: number | null = null;
  if (map.UNTIL) {
    const u = parseDate({ name: "UNTIL", params: {}, value: map.UNTIL });
    until = u ? (u.allDay ? u.ts + 86_400_000 - 1 : u.ts) : null;
  }
  const byday = (map.BYDAY ?? "")
    .split(",")
    .map((d) => DAYS.indexOf(d.replace(/^[+-]?\d+/, "").toUpperCase()))
    .filter((i) => i >= 0);
  return {
    freq,
    interval: Math.max(1, Number(map.INTERVAL) || 1),
    count: map.COUNT ? Math.max(1, Number(map.COUNT) || 1) : null,
    until,
    byday,
  };
}

function dayOfWeek(y: number, mo: number, d: number): number {
  return new Date(Date.UTC(y, mo - 1, d)).getUTCDay();
}

/** Alle Startzeitpunkte einer Wiederholung bis `limit` (Wanduhr-Zeit bleibt über Sommerzeit hinweg gleich). */
function occurrences(start: DateVal, rule: Rule, limit: number): number[] {
  const tz = start.tz;
  const base = toWall(start.ts, tz);
  const out: number[] = [];
  let produced = 0;
  const push = (w: Wall): boolean => {
    const ts = start.allDay ? wallAsUtc({ ...w, h: 0, mi: 0, s: 0 }) : wallToUtc(w, tz);
    if (ts < start.ts) return true;
    if (rule.until !== null && ts > rule.until) return false;
    if (ts > limit) return false;
    produced++;
    out.push(ts);
    return rule.count === null || produced < rule.count;
  };

  const MAX = 4000;
  if (rule.freq === "DAILY") {
    for (let i = 0; i < MAX; i++) {
      const dt = new Date(Date.UTC(base.y, base.mo - 1, base.d + i * rule.interval));
      const w = { ...base, y: dt.getUTCFullYear(), mo: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
      if (!push(w)) break;
    }
  } else if (rule.freq === "WEEKLY") {
    const days = rule.byday.length ? [...rule.byday].sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7)) : [dayOfWeek(base.y, base.mo, base.d)];
    // Wochenbeginn (Montag) der Startwoche
    const startDow = (dayOfWeek(base.y, base.mo, base.d) + 6) % 7;
    outer: for (let wk = 0; wk < MAX; wk++) {
      for (const dow of days) {
        const offset = (dow + 6) % 7;
        const dt = new Date(Date.UTC(base.y, base.mo - 1, base.d - startDow + wk * 7 * rule.interval + offset));
        const w = { ...base, y: dt.getUTCFullYear(), mo: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
        if (!push(w)) break outer;
      }
    }
  } else if (rule.freq === "MONTHLY") {
    for (let i = 0; i < MAX; i++) {
      const dt = new Date(Date.UTC(base.y, base.mo - 1 + i * rule.interval, 1));
      const daysInMonth = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() + 1, 0)).getUTCDate();
      if (base.d > daysInMonth) continue; // z. B. 31. in kürzeren Monaten überspringen
      if (!push({ ...base, y: dt.getUTCFullYear(), mo: dt.getUTCMonth() + 1, d: base.d })) break;
    }
  } else {
    for (let i = 0; i < 200; i++) {
      if (!push({ ...base, y: base.y + i * rule.interval })) break;
    }
  }
  return out;
}

// ---------- Hauptfunktion ----------

type RawEvent = {
  uid: string;
  title: string;
  start: DateVal;
  end: DateVal | null;
  duration: number | null;
  location: string | null;
  description: string | null;
  rule: Rule | null;
  exdates: Set<number>;
  recurrenceId: number | null;
  cancelled: boolean;
};

function parseEvents(text: string): RawEvent[] {
  const lines = unfold(text);
  const events: RawEvent[] = [];
  let current: Prop[] | null = null;

  for (const line of lines) {
    if (line === "BEGIN:VEVENT") {
      current = [];
      continue;
    }
    if (line === "END:VEVENT") {
      if (current) {
        const ev = buildEvent(current, events.length);
        if (ev) events.push(ev);
      }
      current = null;
      continue;
    }
    if (current) {
      const p = parseLine(line);
      if (p) current.push(p);
    }
  }
  return events;
}

function buildEvent(props: Prop[], index: number): RawEvent | null {
  const first = (n: string) => props.find((p) => p.name === n);
  const dtstart = first("DTSTART");
  if (!dtstart) return null;
  const start = parseDate(dtstart);
  if (!start) return null;
  const dtend = first("DTEND");
  const dur = first("DURATION");
  const rrule = first("RRULE");
  const recId = first("RECURRENCE-ID");

  const exdates = new Set<number>();
  for (const p of props.filter((x) => x.name === "EXDATE")) {
    for (const v of p.value.split(",")) {
      const d = parseDate({ ...p, value: v });
      if (d) exdates.add(d.ts);
    }
  }

  return {
    uid: first("UID")?.value ?? `ev-${index}`,
    title: unescapeText(first("SUMMARY")?.value ?? "") || "Ohne Titel",
    start,
    end: dtend ? parseDate(dtend) : null,
    duration: dur ? parseDuration(dur.value) : null,
    location: unescapeText(first("LOCATION")?.value ?? "") || null,
    description: unescapeText(first("DESCRIPTION")?.value ?? "") || null,
    rule: rrule ? parseRule(rrule.value) : null,
    exdates,
    recurrenceId: recId ? (parseDate(recId)?.ts ?? null) : null,
    cancelled: first("STATUS")?.value.trim().toUpperCase() === "CANCELLED",
  };
}

export function parseIcal(text: string, from: Date, to: Date): CalEvent[] {
  const raws = parseEvents(text);
  const fromTs = from.getTime();
  const toTs = to.getTime();
  const result: CalEvent[] = [];

  // Geänderte Einzeltermine ersetzen die passende Wiederholung.
  const overridden = new Set<string>();
  for (const r of raws) if (r.recurrenceId !== null) overridden.add(`${r.uid}|${r.recurrenceId}`);

  for (const r of raws) {
    if (r.cancelled) continue;
    const lengthMs = r.end
      ? Math.max(0, r.end.ts - r.start.ts)
      : (r.duration ?? (r.start.allDay ? 86_400_000 : 0));

    const starts =
      r.rule && r.recurrenceId === null
        ? occurrences(r.start, r.rule, toTs)
        : [r.start.ts];

    for (const s of starts) {
      if (r.rule && r.recurrenceId === null) {
        if (r.exdates.has(s) || overridden.has(`${r.uid}|${s}`)) continue;
      }
      const e = s + lengthMs;
      if (e <= fromTs && !(lengthMs === 0 && s >= fromTs)) continue;
      if (s >= toTs) continue;
      result.push({
        id: `${r.uid}@${s}`,
        title: r.title,
        start: new Date(s),
        end: new Date(e),
        allDay: r.start.allDay,
        location: r.location,
        description: r.description,
      });
    }
  }

  return result.sort((a, b) => a.start.getTime() - b.start.getTime());
}

/** Lädt einen iCal-Feed. Nur https (oder webcal, das als https behandelt wird). */
export async function fetchIcal(rawUrl: string, from: Date, to: Date): Promise<CalEvent[] | null> {
  let url: URL;
  try {
    url = new URL(rawUrl.trim().replace(/^webcal:/i, "https:"));
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;

  try {
    const res = await fetch(url, {
      next: { revalidate: 300 },
      signal: AbortSignal.timeout(10_000),
      headers: { Accept: "text/calendar, text/plain;q=0.8, */*;q=0.5" },
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (text.length > 5_000_000 || !text.includes("BEGIN:VCALENDAR")) return null;
    return parseIcal(text, from, to);
  } catch {
    return null;
  }
}
