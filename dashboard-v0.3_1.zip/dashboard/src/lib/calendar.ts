// Gemeinsame Hilfen für Termine: Abruf (iCal oder Microsoft) und Darstellung.

import { fetchIcal, toWall, wallToUtc, type CalEvent } from "./ical";
import { getGraphEvents, hasMicrosoftSession, msConfig } from "./microsoft";

export function calendarIcalUrl(): string | null {
  return process.env.CALENDAR_ICAL_URL?.trim() || null;
}

export function iservIcalUrl(): string | null {
  return process.env.ISERV_ICAL_URL?.trim() || null;
}

export type CalendarResult =
  | { status: "ok"; source: "ical" | "microsoft"; events: CalEvent[] }
  | { status: "login" }
  | { status: "forbidden" }
  | { status: "unconfigured" }
  | { status: "error" };

/** Kalender: iCal-Link hat Vorrang, sonst Microsoft 365 (nur wenn angemeldet). */
export async function getCalendar(from: Date, to: Date): Promise<CalendarResult> {
  const ical = calendarIcalUrl();
  if (ical) {
    const events = await fetchIcal(ical, from, to);
    return events ? { status: "ok", source: "ical", events } : { status: "error" };
  }
  if (!msConfig()) return { status: "unconfigured" };
  if (!(await hasMicrosoftSession())) return { status: "login" };
  const r = await getGraphEvents(from, to);
  if (r.ok) return { status: "ok", source: "microsoft", events: r.data };
  return r.reason === "login" ? { status: "login" } : r.reason === "forbidden" ? { status: "forbidden" } : { status: "error" };
}

export async function getIservCalendar(from: Date, to: Date): Promise<CalEvent[] | null> {
  const url = iservIcalUrl();
  return url ? fetchIcal(url, from, to) : null;
}

// ---------- Darstellung ----------

const TZ = "Europe/Berlin";

/** Beginn eines Tages (0 Uhr) in Berlin. `offsetDays` verschiebt um ganze Tage. */
export function berlinDayStart(offsetDays = 0, now = new Date()): Date {
  const w = toWall(now.getTime(), TZ);
  const dt = new Date(Date.UTC(w.y, w.mo - 1, w.d + offsetDays));
  return new Date(
    wallToUtc({ y: dt.getUTCFullYear(), mo: dt.getUTCMonth() + 1, d: dt.getUTCDate(), h: 0, mi: 0, s: 0 }, TZ),
  );
}

export function dayKey(d: Date): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(d);
}

export function formatTime(d: Date): string {
  return d.toLocaleTimeString("de-DE", { timeZone: TZ, hour: "2-digit", minute: "2-digit" });
}

export function formatDayLabel(d: Date, now = new Date()): string {
  const key = dayKey(d);
  if (key === dayKey(now)) return "Heute";
  if (key === dayKey(new Date(now.getTime() + 86_400_000))) return "Morgen";
  return d.toLocaleDateString("de-DE", { timeZone: TZ, weekday: "long", day: "numeric", month: "long" });
}

export type DayGroup = { key: string; label: string; events: CalEvent[] };

export function groupByDay(events: CalEvent[], now = new Date()): DayGroup[] {
  const map = new Map<string, DayGroup>();
  for (const e of events) {
    const key = dayKey(e.start);
    if (!map.has(key)) map.set(key, { key, label: formatDayLabel(e.start, now), events: [] });
    map.get(key)!.events.push(e);
  }
  return [...map.values()];
}
