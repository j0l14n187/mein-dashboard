// Öffentliche Statistiken von Chess.com (Published-Data API, kein Passwort nötig).
// Der Abruf passiert auf dem Server und wird zwischengespeichert.

export type ChessMode = {
  key: string;
  label: string;
  rating: number | null;
  best: number | null;
  win: number;
  loss: number;
  draw: number;
};

export type ChessData = {
  username: string;
  followers: number | null;
  modes: ChessMode[];
  tacticsHighest: number | null;
  puzzleRushBest: number | null;
};

export type ChessResult =
  | { status: "ok"; data: ChessData }
  | { status: "notfound" }
  | { status: "error" };

function num(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

function obj(v: unknown): Record<string, unknown> | null {
  return typeof v === "object" && v !== null ? (v as Record<string, unknown>) : null;
}

const MODES: { key: string; label: string }[] = [
  { key: "chess_rapid", label: "Schnellschach" },
  { key: "chess_blitz", label: "Blitz" },
  { key: "chess_bullet", label: "Bullet" },
  { key: "chess_daily", label: "Täglich" },
];

export async function getChess(username: string): Promise<ChessResult> {
  const base = `https://api.chess.com/pub/player/${encodeURIComponent(username.toLowerCase())}`;
  const init = {
    next: { revalidate: 900 },
    signal: AbortSignal.timeout(8000),
    headers: { Accept: "application/json", "User-Agent": "dashboard (privates Schulprojekt)" },
  };

  try {
    const [profileRes, statsRes] = await Promise.all([fetch(base, init), fetch(`${base}/stats`, init)]);
    if (profileRes.status === 404 || statsRes.status === 404) return { status: "notfound" };
    if (!profileRes.ok || !statsRes.ok) return { status: "error" };

    const profile = obj(await profileRes.json());
    const stats = obj(await statsRes.json());
    if (!stats) return { status: "error" };

    const modes: ChessMode[] = [];
    for (const { key, label } of MODES) {
      const m = obj(stats[key]);
      if (!m) continue;
      const record = obj(m.record);
      modes.push({
        key,
        label,
        rating: num(obj(m.last)?.rating),
        best: num(obj(m.best)?.rating),
        win: num(record?.win) ?? 0,
        loss: num(record?.loss) ?? 0,
        draw: num(record?.draw) ?? 0,
      });
    }

    return {
      status: "ok",
      data: {
        username,
        followers: num(profile?.followers),
        modes,
        tacticsHighest: num(obj(obj(stats.tactics)?.highest)?.rating),
        puzzleRushBest: num(obj(obj(stats.puzzle_rush)?.best)?.score),
      },
    };
  } catch {
    return { status: "error" };
  }
}
