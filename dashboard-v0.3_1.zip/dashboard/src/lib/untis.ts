// WebUntis-Stundenplan. Zwei Wege, beide nur lesend und nur auf dem Server:
//  1. iCal-Link (empfohlen, ohne Passwort): UNTIS_ICAL_URL
//  2. Anmeldung über die WebUntis-Schnittstelle (JSON-RPC): UNTIS_SERVER, UNTIS_SCHOOL, UNTIS_USER, UNTIS_PASSWORD
// Welcher Weg bei deiner Schule freigegeben ist, entscheidet die Schule.

import { fetchIcal, wallToUtc, type CalEvent } from "./ical";

export type UntisConfig =
  | { mode: "ical"; url: string }
  | { mode: "api"; server: string; school: string; user: string; password: string };

const HOST = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/i;

export function untisConfig(): UntisConfig | null {
  const ical = process.env.UNTIS_ICAL_URL?.trim();
  if (ical) return { mode: "ical", url: ical };

  const server = process.env.UNTIS_SERVER?.trim().replace(/^https?:\/\//i, "").replace(/\/.*$/, "");
  const school = process.env.UNTIS_SCHOOL?.trim();
  const user = process.env.UNTIS_USER?.trim();
  const password = process.env.UNTIS_PASSWORD;
  if (server && HOST.test(server) && school && user && password) {
    return { mode: "api", server, school, user, password };
  }
  return null;
}

type Named = { name?: string; longname?: string };

function first(v: unknown): Named | null {
  return Array.isArray(v) && typeof v[0] === "object" && v[0] !== null ? (v[0] as Named) : null;
}

function names(v: unknown): string[] {
  return Array.isArray(v)
    ? v.map((x) => (x as Named)?.name).filter((n): n is string => typeof n === "string" && n.length > 0)
    : [];
}

function yyyymmdd(d: Date): number {
  const p = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Berlin" }).format(d); // 2026-10-13
  return Number(p.replace(/-/g, ""));
}

async function rpc<T>(base: string, school: string, cookie: string | null, method: string, params: unknown) {
  const res = await fetch(`${base}/WebUntis/jsonrpc.do?school=${encodeURIComponent(school)}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: JSON.stringify({ id: "dashboard", method, params, jsonrpc: "2.0" }),
    signal: AbortSignal.timeout(10_000),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = (await res.json()) as { result?: T; error?: { message?: string } };
  if (j.error) throw new Error(j.error.message ?? "Fehler");
  return j.result as T;
}

async function fetchViaApi(cfg: Extract<UntisConfig, { mode: "api" }>, from: Date, to: Date): Promise<CalEvent[] | null> {
  const base = `https://${cfg.server}`;
  try {
    const auth = await rpc<{ sessionId: string; personId: number; personType: number }>(base, cfg.school, null, "authenticate", {
      user: cfg.user,
      password: cfg.password,
      client: "dashboard",
    });
    const cookie = `JSESSIONID=${auth.sessionId}; schoolname=_${Buffer.from(cfg.school).toString("base64")}`;

    try {
      const fields = ["id", "name", "longname"];
      const lessons = await rpc<unknown[]>(base, cfg.school, cookie, "getTimetable", {
        options: {
          element: { id: auth.personId, type: auth.personType },
          startDate: yyyymmdd(from),
          endDate: yyyymmdd(to),
          showInfo: true,
          showSubstText: true,
          showLsText: true,
          klasseFields: fields,
          roomFields: fields,
          subjectFields: fields,
          teacherFields: fields,
        },
      });

      const out: CalEvent[] = [];
      for (const raw of Array.isArray(lessons) ? lessons : []) {
        const l = raw as Record<string, unknown>;
        const date = Number(l.date);
        const st = Number(l.startTime);
        const en = Number(l.endTime);
        if (!date || !Number.isFinite(st) || !Number.isFinite(en)) continue;
        const y = Math.floor(date / 10000);
        const mo = Math.floor(date / 100) % 100;
        const d = date % 100;
        const start = wallToUtc({ y, mo, d, h: Math.floor(st / 100), mi: st % 100, s: 0 }, "Europe/Berlin");
        const end = wallToUtc({ y, mo, d, h: Math.floor(en / 100), mi: en % 100, s: 0 }, "Europe/Berlin");

        const subject = first(l.su);
        const rooms = names(l.ro);
        const teachers = names(l.te);
        const code = typeof l.code === "string" ? l.code : null;
        const subst = typeof l.substText === "string" && l.substText.trim() ? l.substText.trim() : null;
        const info = typeof l.lstext === "string" && l.lstext.trim() ? l.lstext.trim() : null;

        out.push({
          id: `untis-${String(l.id ?? `${date}-${st}`)}`,
          title: subject?.longname || subject?.name || "Unterricht",
          start: new Date(start),
          end: new Date(end),
          allDay: false,
          location: rooms.join(", ") || null,
          description: subst ?? info,
          note: teachers.join(", ") || null,
          status: code === "cancelled" ? "cancelled" : code === "irregular" ? "changed" : null,
        });
      }
      return out.sort((a, b) => a.start.getTime() - b.start.getTime());
    } finally {
      // Sitzung bei WebUntis wieder schließen.
      rpc(base, cfg.school, cookie, "logout", {}).catch(() => undefined);
    }
  } catch {
    return null;
  }
}

export async function getTimetable(from: Date, to: Date): Promise<CalEvent[] | null> {
  const cfg = untisConfig();
  if (!cfg) return null;
  return cfg.mode === "ical" ? fetchIcal(cfg.url, from, to) : fetchViaApi(cfg, from, to);
}
