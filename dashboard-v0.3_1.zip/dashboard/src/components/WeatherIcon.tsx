import type { WeatherKind } from "@/lib/weather";

const CLOUD = "M18 46a9 9 0 0 1-.6-18A13 13 0 0 1 42.6 24 10.5 10.5 0 0 1 46 46z";

/** Kleine, animierte Wettersymbole als SVG (Linienstil, Verlaufsfarben). */
export function WeatherIcon({ kind, small = false }: { kind: WeatherKind; small?: boolean }) {
  const id = `wg-${kind}${small ? "-s" : ""}`;
  return (
    <svg
      className={`weather-art${small ? " small" : ""}`}
      viewBox="0 0 64 64"
      fill="none"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id={id} x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="var(--accent)" />
          <stop offset="1" stopColor="var(--accent-2)" />
        </linearGradient>
      </defs>
      <g stroke={`url(#${id})`}>
        {kind === "clear" ? (
          <>
            <circle cx="32" cy="32" r="10" />
            <g className="w-sun-rays">
              <path d="M32 8v6M32 50v6M8 32h6M50 32h6M15 15l4.2 4.2M44.8 44.8 49 49M49 15l-4.2 4.2M19.2 44.8 15 49" />
            </g>
          </>
        ) : null}

        {kind === "partly" ? (
          <>
            <circle cx="24" cy="24" r="8" />
            <g className="w-sun-rays" style={{ transformOrigin: "24px 24px" }}>
              <path d="M24 8v4M8 24h4M12.7 12.7l2.8 2.8M35.3 12.7l-2.8 2.8M24 40v-2" />
            </g>
            <g className="w-cloud">
              <path d={CLOUD} transform="translate(2 0) scale(.92)" />
            </g>
          </>
        ) : null}

        {kind === "cloudy" ? (
          <g className="w-cloud">
            <path d={CLOUD} />
            <path d="M14 22a8 8 0 0 1 12-6" opacity=".5" />
          </g>
        ) : null}

        {kind === "fog" ? (
          <>
            <path d="M16 22a9 9 0 0 1 4-8 12 12 0 0 1 22 3 8 8 0 0 1 4 15H18" className="w-cloud" />
            <path d="M12 44h40M18 51h28" opacity=".7" />
          </>
        ) : null}

        {kind === "rain" ? (
          <>
            <g className="w-cloud">
              <path d="M18 38a9 9 0 0 1-.6-18A13 13 0 0 1 42.6 16 10.5 10.5 0 0 1 46 38z" />
            </g>
            <path className="w-drop" d="M22 46l-2 6" />
            <path className="w-drop" d="M32 46l-2 6" />
            <path className="w-drop" d="M42 46l-2 6" />
          </>
        ) : null}

        {kind === "snow" ? (
          <>
            <g className="w-cloud">
              <path d="M18 38a9 9 0 0 1-.6-18A13 13 0 0 1 42.6 16 10.5 10.5 0 0 1 46 38z" />
            </g>
            <path className="w-drop" d="M21 47v.1M32 49v.1M43 47v.1M26.5 54v.1M37.5 54v.1" strokeWidth="3.4" />
          </>
        ) : null}

        {kind === "storm" ? (
          <>
            <g className="w-cloud">
              <path d="M18 38a9 9 0 0 1-.6-18A13 13 0 0 1 42.6 16 10.5 10.5 0 0 1 46 38z" />
            </g>
            <path d="m33 38-6 9h8l-5 9" />
          </>
        ) : null}
      </g>
    </svg>
  );
}
