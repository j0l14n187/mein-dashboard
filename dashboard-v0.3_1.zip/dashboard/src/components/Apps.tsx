// Die eingebauten Apps (serverseitig gerendert): Teams, Kalender, Dateien, WebUntis und IServ.
// Die Daten holt immer der Server. Der Browser bekommt nur das fertige HTML.

import type { CSSProperties, ReactNode } from "react";
import Link from "next/link";
import { EmbedFrame } from "./EmbedFrame";
import { Icon } from "./Icon";
import {
  berlinDayStart,
  formatTime,
  getCalendar,
  getIservCalendar,
  groupByDay,
  iservIcalUrl,
} from "@/lib/calendar";
import { canEmbed } from "@/lib/embed";
import { embedUrlFor, openLinkFor, untisUrl } from "@/lib/integration-status";
import type { CalEvent } from "@/lib/ical";
import {
  getChats,
  getMessages,
  getRecentFiles,
  hasMicrosoftSession,
  msConfig,
  type TeamsChat,
} from "@/lib/microsoft";
import { getSession } from "@/lib/session";
import { getTimetable, untisConfig } from "@/lib/untis";

const TZ = "Europe/Berlin";

/* ---------- Gemeinsame Bausteine ---------- */

export function Notice({
  children,
  tone,
}: {
  children: ReactNode;
  tone?: "warn" | "danger";
}) {
  return <p className={`notice${tone ? ` ${tone}` : ""}`}>{children}</p>;
}

const ERRORS: Record<string, string> = {
  "nicht-eingerichtet": "Die Microsoft-Anmeldung ist noch nicht eingerichtet (siehe Einrichtung unten).",
  abgebrochen: "Die Anmeldung wurde abgebrochen oder von Microsoft abgelehnt. Vielleicht braucht deine Schule eine Freigabe.",
  ungueltig: "Die Anmeldung konnte nicht bestätigt werden. Bitte versuche es noch einmal.",
  token: "Microsoft hat die Anmeldung nicht abgeschlossen. Prüfe Client-ID, Client-Secret und Redirect-URL in .env.local.",
};

export function LoginErrors({ code }: { code?: string }) {
  if (!code || !ERRORS[code]) return null;
  return <Notice tone="danger">{ERRORS[code]}</Notice>;
}

/** Anmelden- oder Abmelden-Leiste für alle Microsoft-Apps. */
export async function MicrosoftBar({ next }: { next: string }) {
  if (!msConfig()) {
    return (
      <Notice>
        Für Teams, Kalender und Dateien brauchst du eine Microsoft-App-Registrierung. Trage die Werte in{" "}
        <code>.env.local</code> ein (siehe „Einrichtung“ unten) und starte das Dashboard neu.
      </Notice>
    );
  }

  const session = await getSession();
  if (!session) {
    return (
      <div className="panel glow">
        <p className="row-sub" style={{ marginBottom: 14 }}>
          Melde dich einmal mit deinem Microsoft-Konto an. Das Dashboard liest danach nur lesend. Die Anmeldung gilt
          8 Stunden und liegt nur im Speicher des Servers.
        </p>
        {/* Normaler Link statt next/link: Die Anmeldung soll nicht im Voraus geladen werden. */}
        <a href={`/api/auth/microsoft/login?next=${encodeURIComponent(next)}`} className="btn">
          <Icon name="lock" size={18} />
          Mit Microsoft anmelden
        </a>
      </div>
    );
  }

  return (
    <ul className="list">
      <li className="row">
        <span className="row-icon">
          <Icon name="user" size={18} />
        </span>
        <span className="row-body">
          <span className="row-title">{session.data.name ?? "Angemeldet"}</span>
          <span className="row-sub">Mit Microsoft verbunden</span>
        </span>
        <form method="post" action="/api/auth/microsoft/logout">
          <button type="submit" className="text-btn">
            Abmelden
          </button>
        </form>
      </li>
    </ul>
  );
}

function ForbiddenNotice({ what, scope }: { what: string; scope: string }) {
  return (
    <Notice tone="warn">
      Microsoft erlaubt den Zugriff auf {what} nicht. Vermutlich muss die IT deiner Schule die Berechtigung{" "}
      <code>{scope}</code> freigeben. Das ist eine Einstellung der Schule, nicht des Dashboards.
    </Notice>
  );
}

function ErrorNotice() {
  return <Notice tone="warn">Die Daten sind gerade nicht verfügbar. Versuche es später noch einmal.</Notice>;
}

export function EventGroups({ events, empty }: { events: CalEvent[]; empty: string }) {
  if (events.length === 0) return <p className="empty">{empty}</p>;

  return (
    <>
      {groupByDay(events).map((g, gi) => (
        <section
          key={g.key}
          className="day-group"
          data-reveal
          style={{ "--i": Math.min(gi, 3) } as CSSProperties}
        >
          <h3 className="day-label">{g.label}</h3>
          <ul className="list glow">
            {g.events.map((e) => (
              <li
                key={e.id}
                className={`row event${e.status === "cancelled" ? " is-cancelled" : ""}${e.status === "changed" ? " is-changed" : ""}`}
              >
                <span className="event-time">
                  {e.allDay ? (
                    "Ganztag"
                  ) : (
                    <>
                      {formatTime(e.start)}
                      <small>{formatTime(e.end)}</small>
                    </>
                  )}
                </span>
                <span className="row-body">
                  <span className="row-title">{e.title}</span>
                  {e.location || e.note || e.description ? (
                    <span className="row-sub">
                      {[e.location, e.note, e.status ? null : e.description].filter(Boolean).join(" · ")}
                    </span>
                  ) : null}
                </span>
                {e.status === "cancelled" ? <span className="badge danger">Entfällt</span> : null}
                {e.status === "changed" ? <span className="badge warn">Geändert</span> : null}
              </li>
            ))}
          </ul>
        </section>
      ))}
    </>
  );
}

/* ---------- Teams ---------- */

function chatIcon(kind: TeamsChat["kind"]) {
  return kind === "oneOnOne" ? "user" : "chat";
}

function formatWhen(d: Date | null): string {
  if (!d) return "";
  const day = (x: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(x);
  if (day(d) === day(new Date())) return formatTime(d);
  return d.toLocaleDateString("de-DE", { timeZone: TZ, day: "2-digit", month: "2-digit" });
}

export async function TeamsApp({ chatId }: { chatId?: string }) {
  if (!msConfig() || !(await hasMicrosoftSession())) return null;
  const session = await getSession();
  const me = session?.data.userId ?? "";

  if (chatId) {
    const r = await getMessages(chatId, me);
    return (
      <section className="section" aria-labelledby="h-chat">
        <h2 className="section-title" id="h-chat">Chat</h2>
        <Link href="/integrationen/teams" className="back">
          <Icon name="chevron" size={16} />
          Alle Chats
        </Link>
        {!r.ok ? (
          r.reason === "forbidden" ? (
            <ForbiddenNotice what="Chats" scope="Chat.Read" />
          ) : (
            <ErrorNotice />
          )
        ) : r.data.length === 0 ? (
          <p className="empty">Keine Nachrichten gefunden.</p>
        ) : (
          <div className="panel" style={{ padding: 0 }}>
            <div className="msgs">
              {r.data.map((m) => (
                <div key={m.id} className={`msg${m.mine ? " mine" : ""}`}>
                  <span className="msg-who">
                    {m.mine ? "Du" : m.from}
                    {m.at ? ` · ${formatWhen(m.at)}` : ""}
                  </span>
                  <span className="msg-text">{m.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        <p className="footnote">Die Nachrichten werden nur angezeigt, nicht gespeichert. Antworten kannst du in Teams selbst.</p>
      </section>
    );
  }

  const r = await getChats(me);
  return (
    <section className="section" aria-labelledby="h-chats">
      <h2 className="section-title" id="h-chats">Deine Chats</h2>
      {!r.ok ? (
        r.reason === "forbidden" ? (
          <ForbiddenNotice what="deine Chats" scope="Chat.Read" />
        ) : (
          <ErrorNotice />
        )
      ) : r.data.length === 0 ? (
        <p className="empty">Keine Chats gefunden.</p>
      ) : (
        <ul className="list glow">
          {r.data.map((c) => (
            <li key={c.id}>
              <Link href={`/integrationen/teams?chat=${encodeURIComponent(c.id)}`} className="row has-icon chat-item">
                <span className="row-icon" style={{ "--c": "#8f7cff" } as CSSProperties}>
                  <Icon name={chatIcon(c.kind)} size={18} />
                </span>
                <span className="row-body">
                  <span className="row-title">{c.title}</span>
                  {c.preview ? (
                    <span className="row-sub" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {c.previewFrom ? `${c.previewFrom}: ` : ""}
                      {c.preview}
                    </span>
                  ) : null}
                </span>
                <span className="row-trailing">
                  {formatWhen(c.at)}
                  <Icon name="chevron" size={16} />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

/* ---------- Kalender ---------- */

export async function CalendarApp() {
  const from = berlinDayStart(0);
  const to = berlinDayStart(14);
  const r = await getCalendar(from, to);

  return (
    <section className="section" aria-labelledby="h-cal">
      <h2 className="section-title" id="h-cal">Nächste 14 Tage</h2>
      {r.status === "ok" ? (
        <>
          <EventGroups events={r.events} empty="In den nächsten 14 Tagen stehen keine Termine an." />
          <p className="footnote">
            Quelle: {r.source === "ical" ? "Kalender-Link (iCal)" : "Microsoft 365"}. Es wird nichts verändert.
          </p>
        </>
      ) : r.status === "forbidden" ? (
        <ForbiddenNotice what="deinen Kalender" scope="Calendars.Read" />
      ) : r.status === "error" ? (
        <ErrorNotice />
      ) : r.status === "unconfigured" ? (
        <Notice>
          Noch nichts eingerichtet. Trage in <code>.env.local</code> entweder <code>CALENDAR_ICAL_URL</code> (ein
          iCal-Link, funktioniert mit Outlook, Google und vielen Schulplattformen) oder die Microsoft-Werte ein.
        </Notice>
      ) : null}
    </section>
  );
}

/* ---------- Dateien ---------- */

function formatSize(bytes: number | null): string {
  if (bytes === null) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1).replace(".", ",")} MB`;
}

export async function FilesApp() {
  if (!msConfig() || !(await hasMicrosoftSession())) return null;
  const r = await getRecentFiles();

  return (
    <section className="section" aria-labelledby="h-files">
      <h2 className="section-title" id="h-files">Zuletzt verwendet</h2>
      {!r.ok ? (
        r.reason === "forbidden" ? (
          <ForbiddenNotice what="deine Dateien" scope="Files.Read" />
        ) : (
          <ErrorNotice />
        )
      ) : r.data.length === 0 ? (
        <p className="empty">Keine Dateien gefunden.</p>
      ) : (
        <ul className="list glow">
          {r.data.map((f) => {
            const body = (
              <>
                <span className="row-icon" style={{ "--c": "#34d399" } as CSSProperties}>
                  <Icon name={f.isFolder ? "folder" : "file"} size={18} />
                </span>
                <span className="row-body">
                  <span className="row-title" style={{ overflowWrap: "anywhere" }}>{f.name}</span>
                  <span className="row-sub">
                    {f.modified
                      ? f.modified.toLocaleDateString("de-DE", { timeZone: TZ, day: "2-digit", month: "2-digit", year: "numeric" })
                      : ""}
                    {f.size !== null && !f.isFolder ? ` · ${formatSize(f.size)}` : ""}
                  </span>
                </span>
                {f.url ? (
                  <span className="row-trailing">
                    <Icon name="external" size={16} />
                  </span>
                ) : null}
              </>
            );
            return (
              <li key={f.id}>
                {f.url ? (
                  <a href={f.url} className="row has-icon" target="_blank" rel="noopener noreferrer">
                    {body}
                  </a>
                ) : (
                  <div className="row has-icon">{body}</div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      <p className="footnote">Es werden nur Namen und Links angezeigt. Die Dateien öffnen sich in OneDrive.</p>
    </section>
  );
}

/* ---------- WebUntis ---------- */

export async function UntisApp() {
  const cfg = untisConfig();
  const url = untisUrl();
  const link = openLinkFor("untis");
  const embedBlocked = url ? (await canEmbed(url)) === false : false;

  let events: CalEvent[] | null = null;
  if (cfg) events = await getTimetable(berlinDayStart(0), berlinDayStart(7));

  return (
    <>
      <section className="section" aria-labelledby="h-plan">
        <h2 className="section-title" id="h-plan">Stundenplan · nächste 7 Tage</h2>
        {!cfg ? (
          <Notice>
            Noch nicht verbunden. Trage in <code>.env.local</code> den iCal-Link deiner Schule als{" "}
            <code>UNTIS_ICAL_URL</code> ein, oder die Zugangsdaten (siehe „Einrichtung“ unten).
          </Notice>
        ) : events === null ? (
          <ErrorNotice />
        ) : (
          <>
            <EventGroups events={events} empty="In den nächsten 7 Tagen steht kein Unterricht an." />
            <p className="footnote">
              Quelle: WebUntis ({cfg.mode === "ical" ? "iCal-Link" : "Schnittstelle"}). Es wird nichts verändert.
            </p>
          </>
        )}
      </section>

      {url && link ? (
        <section className="section" aria-labelledby="h-live">
          <h2 className="section-title" id="h-live">WebUntis direkt</h2>
          <EmbedFrame url={url} title="WebUntis" openLabel={link.label} blocked={embedBlocked} />
        </section>
      ) : null}
    </>
  );
}

/* ---------- IServ ---------- */

export async function IservApp() {
  const url = embedUrlFor("iserv");
  const link = openLinkFor("iserv");
  const hasIcal = Boolean(iservIcalUrl());
  const embedBlocked = url ? (await canEmbed(url)) === false : false;
  const events = hasIcal ? await getIservCalendar(berlinDayStart(0), berlinDayStart(14)) : null;

  return (
    <>
      {hasIcal ? (
        <section className="section" aria-labelledby="h-iserv-cal">
          <h2 className="section-title" id="h-iserv-cal">IServ-Kalender · nächste 14 Tage</h2>
          {events === null ? (
            <ErrorNotice />
          ) : (
            <>
              <EventGroups events={events} empty="In den nächsten 14 Tagen stehen keine Termine an." />
              <p className="footnote">Quelle: IServ-Kalender (iCal-Link). Es wird nichts verändert.</p>
            </>
          )}
        </section>
      ) : null}

      {url && link ? (
        <section className="section" aria-labelledby="h-iserv-live">
          <h2 className="section-title" id="h-iserv-live">IServ direkt</h2>
          <EmbedFrame url={url} title="IServ" openLabel={link.label} blocked={embedBlocked} />
        </section>
      ) : (
        <Notice>
          Noch keine IServ-Adresse eingetragen. Setze in <code>.env.local</code> die Zeile{" "}
          <code>ISERV_URL=https://deineschule.de</code> und optional <code>ISERV_ICAL_URL</code> für deinen Kalender.
        </Notice>
      )}
    </>
  );
}
