"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { Icon } from "./Icon";

type Task = { id: string; title: string; done: boolean };

const STORAGE_KEY = "dashboard.tasks.v1";
// Früherer Schlüssel (vor der Umbenennung): wird einmalig übernommen, damit keine Aufgaben verloren gehen.
const LEGACY_KEY = "nexus.tasks.v1";

function newId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : String(Date.now() + Math.random());
}

export function TaskDemo() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [text, setText] = useState("");
  const [loaded, setLoaded] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Aufgaben nur lokal im Browser lesen (localStorage). Es wird nichts an einen Server gesendet.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY) ?? window.localStorage.getItem(LEGACY_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setTasks(
            parsed.filter(
              (t): t is Task =>
                typeof t === "object" &&
                t !== null &&
                typeof (t as Task).id === "string" &&
                typeof (t as Task).title === "string" &&
                typeof (t as Task).done === "boolean",
            ),
          );
        }
      }
    } catch {
      // Speicher nicht verfügbar oder beschädigt: einfach leer starten.
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      // Speichern nicht möglich (z. B. privater Modus). Die Liste bleibt trotzdem nutzbar.
    }
  }, [tasks, loaded]);

  function add(e: FormEvent) {
    e.preventDefault();
    const title = text.trim().slice(0, 200);
    if (!title) return;
    setTasks((prev) => [{ id: newId(), title, done: false }, ...prev]);
    setText("");
    inputRef.current?.focus();
  }

  function toggle(id: string) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function remove(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  function clearDone() {
    setTasks((prev) => prev.filter((t) => !t.done));
  }

  const doneCount = tasks.filter((t) => t.done).length;

  return (
    <div>
      <form onSubmit={add} className="list">
        <div className="row field-row">
          <label htmlFor="new-task" className="visually-hidden">
            Neue Aufgabe
          </label>
          <input
            id="new-task"
            ref={inputRef}
            className="field"
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Neue Aufgabe"
            maxLength={200}
            autoComplete="off"
            enterKeyHint="done"
          />
          <button type="submit" className="icon-btn" aria-label="Aufgabe hinzufügen" disabled={!text.trim()}>
            <Icon name="plus" size={20} />
          </button>
        </div>
      </form>

      {loaded && tasks.length === 0 ? (
        <p className="empty">Noch keine Aufgaben. Füge oben die erste hinzu.</p>
      ) : (
        <ul className="list task-list" aria-label="Aufgaben">
          {tasks.map((t) => (
            <li key={t.id} className="row task-row">
              <button
                type="button"
                className={`check${t.done ? " is-done" : ""}`}
                onClick={() => toggle(t.id)}
                role="checkbox"
                aria-checked={t.done}
                aria-label={t.done ? `„${t.title}“ als offen markieren` : `„${t.title}“ als erledigt markieren`}
              >
                {t.done ? <Icon name="check" size={14} /> : null}
              </button>
              <span className={`task-title${t.done ? " is-done" : ""}`}>{t.title}</span>
              <button type="button" className="text-btn danger" onClick={() => remove(t.id)}>
                Löschen
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className="task-footer">
        <p className="footnote">Deine Aufgaben werden nur in diesem Browser gespeichert und nicht an einen Server gesendet.</p>
        {doneCount > 0 ? (
          <button type="button" className="text-btn" onClick={clearDone}>
            Erledigte entfernen ({doneCount})
          </button>
        ) : null}
      </div>
    </div>
  );
}
