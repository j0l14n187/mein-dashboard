// Die Karten der Übersicht. Jede lädt ihre Daten selbst und wird in <Suspense> eingebunden,
// damit die Seite sofort steht und die Karten nacheinander erscheinen.

import Link from "next/link";
import { Icon } from "./Icon";
import { NewsHero } from "./NewsCards";
import { WeatherIcon } from "./WeatherIcon";
import { berlinDayStart, formatDayLabel, formatTime, getCalendar, groupByDay } from "@/lib/calendar";
import type { CalEvent } from "@/lib/ical";
import { getNews } from "@/lib/tagesschau";
import { getTimetable, untisConfig } from "@/lib/untis";
import { describeWeather, getWeather, weatherKind } from "@/lib/weather";

// Beispieldaten – nur sichtbar, solange WebUntis nicht verbunden ist.
const demoLessons = [
  { time: "08:00", subject: "Mathematik", room: "Raum 204" },
  { time: "09:45", subject: "Deutsch", room: "Raum 112" },
  { time: "11:30", subject: "Englisch", room: "Raum 108" },
];

function CardHead({ title, href, label = "Öffnen" }: { title: string; href: string; label?: string }) {
  return (
    <div className="card-head">
      <h2 className="card-title">{title}</h2>
      <Link href={href} className="card-link">
        {label}
        <Icon name="chevron" size={13} />
      </Link>
    </div>
  );
}

export function CardSkeleton({ tall = false }: { tall?: boolean }) {
  return <div className={`skeleton${tall ? " tall" : ""}`} aria-hidden="true" />;
}

/* ---------- Stundenplan ---------- */

export async function TimetableCard() {
  const cfg = untisConfig();
  let events: CalEvent[] | null = null;
  if (cfg) events = await getTimetable(berlinDayStart(0), berlinDayStart(4));

  // Heute, oder der nächste Tag mit Unterricht.
  const group = events ? groupByDay(events)[0] : null;

  return (
    <div className="card glow">
      <CardHead title={group ? `Stundenplan · ${group.label}` : "Stundenplan"} href="/integrationen/untis" label="Alle" />

      {!cfg ? (
        <>
          <ul className="list">
            {demoLessons.map((l) => (
              <li key={l.time} className="row">
                <span className="time">{l.time}</span>
                <span className="row-body">
                  <span className="row-title">{l.subject}</span>
                  <span className="row-sub">{l.room}</span>
                </span>
              </li>
            ))}
          </ul>
          <p className="footnote" style={{ marginLeft: 0 }}>
            Beispieldaten. <Link href="/integrationen/untis">WebUntis verbinden</Link>, um deinen echten Stundenplan zu sehen.
          </p>
        </>
      ) : events === null ? (
        <p className="notice">Der Stundenplan ist gerade nicht erreichbar.</p>
      ) : !group ? (
        <p className="empty" style={{ margin: "20px 0" }}>In den nächsten Tagen steht kein Unterricht an.</p>
      ) : (
        <ul className="list">
          {group.events.slice(0, 7).map((e) => (
            <li key={e.id} className={`row event${e.status === "cancelled" ? " is-cancelled" : ""}${e.status === "changed" ? " is-changed" : ""}`}>
              <span className="event-time">
                {formatTime(e.start)}
                <small>{formatTime(e.end)}</small>
              </span>
              <span className="row-body">
                <span className="row-title">{e.title}</span>
                {e.location || e.note ? <span className="row-sub">{[e.location, e.note].filter(Boolean).join(" · ")}</span> : null}
              </span>
              {e.status === "cancelled" ? <span className="badge danger">Entfällt</span> : null}
              {e.status === "changed" ? <span className="badge warn">Geändert</span> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------- Wetter ---------- */

export async function WeatherCard() {
  const weather = await getWeather();
  const today = weather?.days[0];

  return (
    <div className="card glow">
      <CardHead title="Wetter · Wipperfürth" href="/aktuelles" />
      {weather ? (
        <div className="weather-now" style={{ padding: 0 }}>
          <WeatherIcon kind={weatherKind(weather.code)} />
          <span className="temp">{Math.round(weather.temperature)}°</span>
          <span className="row-body">
            <span className="row-title">{describeWeather(weather.code)}</span>
            <span className="row-sub">
              {today ? `${Math.round(today.max)}° / ${Math.round(today.min)}°` : ""}
              {weather.wind !== null ? ` · Wind ${Math.round(weather.wind)} km/h` : ""}
            </span>
          </span>
        </div>
      ) : (
        <p className="notice">Das Wetter ist gerade nicht verfügbar.</p>
      )}
    </div>
  );
}

/* ---------- Titelgeschichte ---------- */

export async function TopNewsCard() {
  const news = await getNews(3);
  const top = news?.[0];
  if (!top) {
    return (
      <div className="card">
        <CardHead title="Nachrichten" href="/aktuelles" />
        <p className="notice">Die Schlagzeilen sind gerade nicht verfügbar.</p>
      </div>
    );
  }
  return <NewsHero item={top} />;
}

/* ---------- Termine ---------- */

export async function EventsCard() {
  const now = new Date();
  const r = await getCalendar(berlinDayStart(0), berlinDayStart(7));

  return (
    <div className="card glow">
      <CardHead title="Termine" href="/integrationen/kalender" label="Kalender" />

      {r.status === "ok" ? (
        r.events.length === 0 ? (
          <p className="empty" style={{ margin: "20px 0" }}>Keine Termine in den nächsten 7 Tagen.</p>
        ) : (
          <ul className="list">
            {r.events.slice(0, 5).map((e) => (
              <li key={e.id} className="row event">
                <span className="event-time">
                  {e.allDay ? "Ganztag" : formatTime(e.start)}
                  <small>{formatDayLabel(e.start, now).split(",")[0]}</small>
                </span>
                <span className="row-body">
                  <span className="row-title">{e.title}</span>
                  {e.location ? <span className="row-sub">{e.location}</span> : null}
                </span>
              </li>
            ))}
          </ul>
        )
      ) : r.status === "login" ? (
        <p className="notice">
          <Link href="/integrationen/kalender">Mit Microsoft anmelden</Link>, um deine Termine zu sehen.
        </p>
      ) : r.status === "unconfigured" ? (
        <p className="notice">
          Noch kein Kalender verbunden. <Link href="/integrationen/kalender">Jetzt einrichten</Link>.
        </p>
      ) : (
        <p className="notice">Die Termine sind gerade nicht verfügbar.</p>
      )}
    </div>
  );
}
