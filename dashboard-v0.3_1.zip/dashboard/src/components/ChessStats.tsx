import { getChess } from "@/lib/chess";
import { chessUsername } from "@/lib/integration-status";

export async function ChessStats() {
  const username = chessUsername();

  if (!username) {
    return (
      <section className="section">
        <p className="notice">
          Noch kein Nutzername eingetragen. Füge in der Datei <code>.env.local</code> die Zeile{" "}
          <code>CHESSCOM_USERNAME=dein-name</code> hinzu und starte das Dashboard neu.
        </p>
      </section>
    );
  }

  const result = await getChess(username);

  if (result.status === "notfound") {
    return (
      <section className="section">
        <p className="notice">Das Konto „{username}“ wurde bei Chess.com nicht gefunden. Prüfe die Schreibweise.</p>
      </section>
    );
  }

  if (result.status === "error") {
    return (
      <section className="section">
        <p className="notice">Die Statistiken sind gerade nicht verfügbar. Versuche es später noch einmal.</p>
      </section>
    );
  }

  const { data } = result;

  return (
    <>
      <section className="section" aria-labelledby="h-ratings">
        <h2 className="section-title" id="h-ratings">Wertungen · {data.username}</h2>
        {data.modes.length > 0 ? (
          <ul className="list glow">
            {data.modes.map((m) => {
              const total = m.win + m.draw + m.loss;
              const pct = (n: number) => (total > 0 ? (n / total) * 100 : 0);
              return (
                <li key={m.key} className="row">
                  <span className="row-body">
                    <span className="row-title">{m.label}</span>
                    <span className="row-sub">
                      {m.win} Siege · {m.draw} Remis · {m.loss} Niederlagen
                      {m.best !== null ? ` · Beste Wertung ${m.best}` : ""}
                    </span>
                    {total > 0 ? (
                      <span className="bar" role="img" aria-label={`${Math.round(pct(m.win))} % Siege`}>
                        <span className="w" style={{ width: `${pct(m.win)}%` }} />
                        <span className="d" style={{ width: `${pct(m.draw)}%` }} />
                        <span className="l" style={{ width: `${pct(m.loss)}%` }} />
                      </span>
                    ) : null}
                  </span>
                  <span className="rating">{m.rating ?? "–"}</span>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="notice">Es sind noch keine Partien gewertet.</p>
        )}
      </section>

      <section className="section" aria-labelledby="h-more" data-reveal>
        <h2 className="section-title" id="h-more">Mehr</h2>
        <ul className="list glow">
          <li className="row">
            <span className="row-body">
              <span className="row-title">Taktik, höchste Wertung</span>
            </span>
            <span className="row-trailing">{data.tacticsHighest ?? "–"}</span>
          </li>
          <li className="row">
            <span className="row-body">
              <span className="row-title">Puzzle Rush, beste Punktzahl</span>
            </span>
            <span className="row-trailing">{data.puzzleRushBest ?? "–"}</span>
          </li>
          <li className="row">
            <span className="row-body">
              <span className="row-title">Follower</span>
            </span>
            <span className="row-trailing">{data.followers ?? "–"}</span>
          </li>
        </ul>
        <p className="footnote">
          Öffentliche Daten von{" "}
          <a href="https://www.chess.com/" target="_blank" rel="noopener noreferrer">
            Chess.com
          </a>
          , alle 15 Minuten aktualisiert.
        </p>
      </section>
    </>
  );
}
