"use client";

import { useState } from "react";
import { Icon } from "./Icon";

/**
 * Live-Ansicht einer externen Seite im Dashboard. Der Rahmen wird erst nach einem Klick geladen,
 * damit ohne dein Zutun keine Verbindung zum Dienst entsteht.
 */
export function EmbedFrame({
  url,
  title,
  openLabel,
  blocked,
}: {
  url: string;
  title: string;
  openLabel: string;
  /** true: Der Dienst verbietet das Einbetten (per Server-Prüfung festgestellt). */
  blocked: boolean;
}) {
  const [shown, setShown] = useState(false);

  if (blocked) {
    return (
      <div className="notice warn">
        {title} erlaubt es nicht, in andere Seiten eingebettet zu werden (das ist eine Sicherheitsregel des Dienstes).
        Deshalb zeigt das Dashboard hier die Daten über die Anbindung oben an. Die Originalseite öffnest du mit dem
        Knopf.
        <div className="btn-row">
          <a href={url} className="btn ghost" target="_blank" rel="noopener noreferrer">
            {openLabel}
            <Icon name="external" size={16} />
          </a>
        </div>
      </div>
    );
  }

  if (!shown) {
    return (
      <div className="panel glow">
        <p className="row-sub" style={{ marginBottom: 14 }}>
          Zeigt {title} direkt hier an. Wenn der Rahmen leer bleibt, verbietet der Dienst das Einbetten. Dann hilft der
          Knopf „Neuer Tab“.
        </p>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <button type="button" className="btn" onClick={() => setShown(true)}>
            Live-Ansicht laden
          </button>
          <a href={url} className="btn ghost" target="_blank" rel="noopener noreferrer">
            {openLabel}
            <Icon name="external" size={16} />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="frame-wrap">
      <div className="frame-bar">
        <span>{title} · Live-Ansicht</span>
        <span>
          <button type="button" className="text-btn" onClick={() => setShown(false)}>
            Schließen
          </button>
          <a href={url} target="_blank" rel="noopener noreferrer">
            Neuer Tab
          </a>
        </span>
      </div>
      <iframe
        src={url}
        title={`${title} (Live-Ansicht)`}
        referrerPolicy="no-referrer"
        sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"
      />
    </div>
  );
}
