import type { CSSProperties } from "react";
import { Icon } from "./Icon";
import { NewsImage } from "./NewsImage";
import { ressortLabel, type NewsItem } from "@/lib/tagesschau";

const TZ = "Europe/Berlin";

export function formatNewsDate(iso: string | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  const day = (x: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(x);
  const time = d.toLocaleTimeString("de-DE", { timeZone: TZ, hour: "2-digit", minute: "2-digit" });
  if (day(d) === day(new Date())) return `Heute, ${time}`;
  if (day(d) === day(new Date(Date.now() - 86_400_000))) return `Gestern, ${time}`;
  return `${d.toLocaleDateString("de-DE", { timeZone: TZ, day: "2-digit", month: "2-digit" })}., ${time}`;
}

function Meta({ item }: { item: NewsItem }) {
  const ressort = ressortLabel(item.ressort);
  const date = formatNewsDate(item.date);
  if (!ressort && !date) return null;
  return (
    <div className="news-meta">
      {ressort ? <span className="chip">{ressort}</span> : null}
      {date ? <time dateTime={item.date ?? undefined}>{date}</time> : null}
    </div>
  );
}

/** Große Titelgeschichte mit Bild. */
export function NewsHero({ item }: { item: NewsItem }) {
  return (
    <a href={item.url} className="news-hero glow" target="_blank" rel="noopener noreferrer">
      <NewsImage image={item.image} priority />
      {item.image?.credit ? <span className="news-credit">{item.image.credit}</span> : null}
      <span className="news-hero-body">
        <Meta item={item} />
        {item.topline ? <span className="news-meta"><span>{item.topline}</span></span> : null}
        <h3 className="news-hero-title">{item.title}</h3>
        {item.teaser ? <p className="news-hero-teaser">{item.teaser}</p> : null}
      </span>
    </a>
  );
}

/** Karte mit Bild oben. */
export function NewsCard({ item, index = 0 }: { item: NewsItem; index?: number }) {
  return (
    <a
      href={item.url}
      className="card news-card glow"
      target="_blank"
      rel="noopener noreferrer"
      data-reveal
      style={{ "--i": index } as CSSProperties}
    >
      <span className="news-thumb">
        <NewsImage image={item.image} />
      </span>
      <span className="news-card-body">
        <Meta item={item} />
        <h3 className="news-card-title">{item.title}</h3>
        {item.teaser ? <span className="row-sub">{item.teaser}</span> : null}
        {item.image?.credit ? <span className="news-credit-note">{item.image.credit}</span> : null}
      </span>
    </a>
  );
}

/** Kompakte Zeile mit kleinem Bild rechts, wie in Nachrichten-Apps. */
export function NewsRow({ item, index = 0 }: { item: NewsItem; index?: number }) {
  return (
    <a
      href={item.url}
      className="card news-row glow"
      target="_blank"
      rel="noopener noreferrer"
      data-reveal
      style={{ "--i": index } as CSSProperties}
    >
      <span className="news-row-body">
        <Meta item={item} />
        <h3 className="news-row-title">{item.title}</h3>
      </span>
      <span className="news-thumb">
        <NewsImage image={item.image} />
      </span>
    </a>
  );
}

export function SourceNote() {
  return (
    <p className="footnote">
      Quelle:{" "}
      <a href="https://www.tagesschau.de/" target="_blank" rel="noopener noreferrer">
        tagesschau.de
      </a>
      . Überschriften, Anreißer und Bilder (mit Bildnachweis) stammen von dort. Ein Tipp auf einen Beitrag öffnet
      ihn auf der Seite der Tagesschau. <Icon name="external" size={11} />
    </p>
  );
}
