"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Icon, type IconName } from "./Icon";
import { integrations } from "@/lib/integrations";
import { Motion } from "./Motion";

type NavItem = { href: string; label: string; icon: IconName };

const nav: NavItem[] = [
  { href: "/", label: "Übersicht", icon: "home" },
  { href: "/aktuelles", label: "Aktuelles", icon: "news" },
  { href: "/aufgaben", label: "Aufgaben", icon: "tasks" },
  { href: "/claude", label: "Claude", icon: "sparkle" },
  { href: "/integrationen", label: "Apps", icon: "grid" },
];

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname() ?? "/";
  const onIntegrations = isActive(pathname, "/integrationen");
  // null = automatisch (offen, solange man in den Integrationen ist)
  const [manual, setManual] = useState<boolean | null>(null);
  const open = manual ?? onIntegrations;

  return (
    <div className="app">
      <div className="scroll-progress" aria-hidden="true" />
      <Motion />
      <aside className="sidebar" aria-label="Seitenleiste">
        <Link href="/" className="brand">
          <span className="brand-mark" aria-hidden="true">JK</span>
          <span>Dashboard</span>
        </Link>
        <nav aria-label="Hauptnavigation">
          <ul className="side-list">
            {nav.map((item) => {
              if (item.href !== "/integrationen") {
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="side-link"
                      aria-current={isActive(pathname, item.href) ? "page" : undefined}
                    >
                      <Icon name={item.icon} size={20} />
                      <span>{item.label}</span>
                    </Link>
                  </li>
                );
              }

              return (
                <li key={item.href}>
                  <div className="side-group-head">
                    <Link
                      href={item.href}
                      className="side-link grow"
                      aria-current={pathname === item.href ? "page" : undefined}
                    >
                      <Icon name={item.icon} size={20} />
                      <span>{item.label}</span>
                    </Link>
                    <button
                      type="button"
                      className="side-toggle"
                      aria-expanded={open}
                      aria-controls="side-sub"
                      aria-label={open ? "Apps zuklappen" : "Apps aufklappen"}
                      onClick={() => setManual(!open)}
                    >
                      <Icon name="chevron" size={16} />
                    </button>
                  </div>
                  <div className={`side-sub-wrap${open ? " open" : ""}`} inert={!open}>
                    <ul id="side-sub" className="side-sub">
                      {integrations.map((i) => (
                        <li key={i.slug}>
                          <Link
                            href={`/integrationen/${i.slug}`}
                            className="side-link sub"
                            aria-current={pathname === `/integrationen/${i.slug}` ? "page" : undefined}
                          >
                            <Icon name={i.icon} size={16} />
                            <span>{i.title}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>

      <div className="content">
        <main id="main">{children}</main>
        <footer className="legal-footer">
          <Link href="/impressum">Impressum</Link>
          <Link href="/datenschutz">Datenschutz</Link>
        </footer>
      </div>

      <nav className="tabbar" aria-label="Hauptnavigation">
        {nav.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="tab"
            aria-current={isActive(pathname, item.href) ? "page" : undefined}
          >
            <Icon name={item.icon} size={24} />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
