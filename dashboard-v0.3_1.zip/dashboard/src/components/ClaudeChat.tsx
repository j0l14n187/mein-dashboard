"use client";

import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { Icon } from "./Icon";

type Msg = { role: "user" | "assistant"; content: string };

const MAX_HISTORY = 20;

function recent(messages: Msg[]): Msg[] {
  const slice = messages.slice(-MAX_HISTORY);
  // Die Anfrage muss mit einer Nutzer-Nachricht beginnen.
  return slice[0]?.role === "assistant" ? slice.slice(1) : slice;
}

export function ClaudeChat({ configured }: { configured: boolean }) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages, busy]);

  async function send(e?: FormEvent) {
    e?.preventDefault();
    const content = text.trim();
    if (!content || busy) return;

    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setText("");
    setBusy(true);
    setError(null);

    try {
      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: recent(next) }),
      });
      const data = (await res.json().catch(() => null)) as { reply?: string; error?: string } | null;
      if (!res.ok || !data?.reply) throw new Error(data?.error ?? "Es ist ein Fehler aufgetreten.");
      setMessages([...next, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Es ist ein Fehler aufgetreten.");
    } finally {
      setBusy(false);
    }
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      void send();
    }
  }

  if (!configured) {
    return (
      <div className="notice">
        Der Chat ist noch nicht eingerichtet. Dafür brauchst du einen API-Schlüssel von Anthropic. Trage ihn in der
        Datei <code>.env.local</code> als <code>ANTHROPIC_API_KEY</code> ein und starte das Dashboard neu. Die
        Schritte stehen unten.
      </div>
    );
  }

  return (
    <div className="chat">
      <div className="chat-log" aria-live="polite">
        {messages.length === 0 ? (
          <p className="empty">Stelle Claude eine Frage.</p>
        ) : (
          messages.map((m, i) => (
            <div key={i} className={`bubble ${m.role}`}>
              {m.content}
            </div>
          ))
        )}
        {busy ? <div className="bubble assistant typing">Claude schreibt …</div> : null}
        {error ? (
          <p className="chat-error" role="alert">
            {error}
          </p>
        ) : null}
        <div ref={endRef} />
      </div>

      <form onSubmit={send} className="chat-form">
        <label htmlFor="chat-input" className="visually-hidden">
          Nachricht an Claude
        </label>
        <textarea
          id="chat-input"
          className="chat-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Nachricht"
          rows={1}
          maxLength={4000}
        />
        <button type="submit" className="icon-btn" aria-label="Senden" disabled={busy || !text.trim()}>
          <Icon name="send" size={20} />
        </button>
      </form>

      <div className="task-footer">
        <p className="footnote">
          Deine Nachrichten werden zur Beantwortung an Anthropic gesendet. Gib keine Passwörter und keine Daten
          anderer Personen ein. Der Verlauf wird nicht gespeichert.
        </p>
        {messages.length > 0 ? (
          <button
            type="button"
            className="text-btn"
            onClick={() => {
              setMessages([]);
              setError(null);
            }}
          >
            Neues Gespräch
          </button>
        ) : null}
      </div>
    </div>
  );
}
