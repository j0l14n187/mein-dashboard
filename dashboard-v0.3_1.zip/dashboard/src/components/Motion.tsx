"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

/**
 * Bewegung auf der ganzen Seite (unsichtbar, rendert nichts):
 *  1. Einblenden beim Scrollen: Elemente mit data-reveal werden beim Heranscrollen weich eingeblendet.
 *     Elemente in Gruppen bekommen gestaffelte Verzögerungen (--i).
 *  2. Lichtkegel: Flächen mit der Klasse „glow" folgen dem Mauszeiger.
 *  3. Scroll-Fortschrittsleiste oben.
 * Bei „Bewegung reduzieren" passiert nichts, und ohne JavaScript bleibt alles einfach sichtbar.
 */
export function Motion() {
  const pathname = usePathname();

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (!("IntersectionObserver" in window)) return;
    const root = document.getElementById("main");
    if (!root) return;

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            io.unobserve(entry.target);
          }
        }
      },
      { rootMargin: "0px 0px -4% 0px", threshold: 0.04 },
    );

    const scan = () => {
      const items = root.querySelectorAll<HTMLElement>("[data-reveal]:not([data-seen])");

      // Elemente in Gruppen zusammenfassen, damit Geschwister gestaffelt eingeblendet werden.
      // Zwei Elemente gelten als Gruppe, wenn sie denselben Parent haben.
      const groups = new Map<Element, HTMLElement[]>();
      items.forEach((el) => {
        const parent = el.parentElement ?? root;
        if (!groups.has(parent)) groups.set(parent, []);
        groups.get(parent)!.push(el);
      });

      groups.forEach((siblings) => {
        siblings.forEach((el, idx) => {
          el.setAttribute("data-seen", "1");
          // Schon sichtbar: CSS-Einflug reicht.
          if (el.getBoundingClientRect().top < window.innerHeight * 0.94) return;
          // Gestaffelte Verzögerung für Geschwister in derselben Gruppe.
          el.style.setProperty("--i", String(idx));
          el.classList.add("reveal-pending");
          io.observe(el);
        });
      });
    };

    scan();
    // Auch Inhalte erfassen, die nachgeladen werden (Streaming / Suspense).
    const mo = new MutationObserver(scan);
    mo.observe(root, { childList: true, subtree: true });

    return () => {
      io.disconnect();
      mo.disconnect();
    };
  }, [pathname]);

  // Lichtkegel: folgt dem Mauszeiger auf .glow-Flächen.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (window.matchMedia("(hover: none)").matches) return;

    let frame = 0;
    const onMove = (e: PointerEvent) => {
      const target = e.target instanceof Element ? e.target.closest<HTMLElement>(".glow") : null;
      if (!target) return;
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const r = target.getBoundingClientRect();
        target.style.setProperty("--mx", `${e.clientX - r.left}px`);
        target.style.setProperty("--my", `${e.clientY - r.top}px`);
      });
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      document.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(frame);
    };
  }, []);

  return null;
}
