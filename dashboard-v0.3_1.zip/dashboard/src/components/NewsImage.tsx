"use client";

import { useState } from "react";
import { Icon } from "./Icon";
import type { NewsImage as Img } from "@/lib/tagesschau";

/** Nachrichtenbild mit Platzhalter, falls das Bild nicht geladen werden kann. */
export function NewsImage({ image, priority = false }: { image: Img | null; priority?: boolean }) {
  const [failed, setFailed] = useState(false);

  if (!image || failed) {
    return (
      <span className="news-ph" aria-hidden="true">
        <Icon name="image" size={34} />
      </span>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      className="news-img"
      src={image.src}
      alt={image.alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      onError={() => setFailed(true)}
    />
  );
}
