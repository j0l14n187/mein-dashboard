import type { ReactNode } from "react";

// Eine template.tsx wird bei jedem Seitenwechsel neu aufgebaut. Dadurch fährt der Inhalt jeder neuen
// Seite (und jedes neu geöffneten Punkts) mit der Animation „page-enter“ ein.
export default function Template({ children }: { children: ReactNode }) {
  return <div className="page-enter">{children}</div>;
}
