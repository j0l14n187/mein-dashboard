import type { MetadataRoute } from "next";

// Privates Dashboard: Suchmaschinen sollen nichts indexieren.
export default function robots(): MetadataRoute.Robots {
  return { rules: { userAgent: "*", disallow: "/" } };
}
