import type { Metadata } from "next";
import type { CSSProperties } from "react";
import Link from "next/link";
import { Icon } from "@/components/Icon";
import { getStatuses } from "@/lib/integration-status";
import { integrations } from "@/lib/integrations";

export const metadata: Metadata = { title: "Apps" };
export const dynamic = "force-dynamic";

export default async function IntegrationenPage() {
  const statuses = await getStatuses();

  return (
    <>
      <div>
        <p className="eyebrow">Alles an einem Ort</p>
        <h1 className="large-title">Apps</h1>
        <p className="lede">Deine Dienste, direkt im Dashboard geöffnet und nicht nur verlinkt.</p>
      </div>

      <ul className="list glow">
        {integrations.map((i) => {
          const status = statuses[i.slug];
          return (
            <li key={i.slug}>
              <Link href={`/integrationen/${i.slug}`} className="row has-icon">
                <span className="row-icon" style={{ "--c": i.color } as CSSProperties}>
                  <Icon name={i.icon} size={18} />
                </span>
                <span className="row-body">
                  <span className="row-title">{i.title}</span>
                  <span className="row-sub">{i.subtitle}</span>
                </span>
                <span className="row-trailing">
                  <span className={`badge ${status?.connected ? "on" : "off"}`}>{status?.label}</span>
                  <Icon name="chevron" size={16} />
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      <p className="footnote">
        Dieses Dashboard ist ein unabhängiges Projekt und steht in keiner Verbindung zu den genannten Unternehmen.
        Produktnamen sind Marken der jeweiligen Inhaber.
      </p>
    </>
  );
}
