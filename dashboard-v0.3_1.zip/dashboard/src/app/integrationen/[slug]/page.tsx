import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { CalendarApp, FilesApp, IservApp, LoginErrors, MicrosoftBar, TeamsApp, UntisApp } from "@/components/Apps";
import { ChessStats } from "@/components/ChessStats";
import { Icon } from "@/components/Icon";
import { calendarIcalUrl } from "@/lib/calendar";
import { getStatuses, openLinkFor } from "@/lib/integration-status";
import { getIntegration } from "@/lib/integrations";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ chat?: string; fehler?: string }>;
};

// Liest .env.local und die Anmeldung zur Laufzeit.
export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const item = getIntegration(slug);
  return { title: item ? item.title : "App" };
}

function Loading() {
  return <div className="skeleton tall" aria-hidden="true" />;
}

export default async function IntegrationPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { chat, fehler } = await searchParams;
  const item = getIntegration(slug);
  if (!item) notFound();

  const statuses = await getStatuses();
  const status = statuses[item.slug] ?? { label: "Nicht eingerichtet", connected: false };
  const link = openLinkFor(item.slug);

  return (
    <>
      <div>
        <Link href="/integrationen" className="back">
          <Icon name="chevron" size={16} />
          Apps
        </Link>
        <p className="eyebrow">{item.subtitle}</p>
        <h1 className="large-title">{item.title}</h1>
        <p className="lede">{item.summary}</p>
      </div>

      <div className="btn-row" style={{ marginTop: 0, marginBottom: 8, alignItems: "center" }}>
        <span className={`badge ${status.connected ? "on" : "off"}`}>{status.label}</span>
        {link ? (
          <a href={link.url} className="btn ghost" target="_blank" rel="noopener noreferrer" style={{ minHeight: 40, padding: "0 16px", fontSize: 13.5 }}>
            {link.label}
            <Icon name="external" size={15} />
          </a>
        ) : null}
      </div>

      <LoginErrors code={fehler} />

      {item.slug === "teams" ? (
        <>
          <MicrosoftBar next="/integrationen/teams" />
          <Suspense fallback={<Loading />}>
            <TeamsApp chatId={chat} />
          </Suspense>
        </>
      ) : null}

      {item.slug === "kalender" ? (
        <>
          {calendarIcalUrl() ? null : <MicrosoftBar next="/integrationen/kalender" />}
          <Suspense fallback={<Loading />}>
            <CalendarApp />
          </Suspense>
        </>
      ) : null}

      {item.slug === "dateien" ? (
        <>
          <MicrosoftBar next="/integrationen/dateien" />
          <Suspense fallback={<Loading />}>
            <FilesApp />
          </Suspense>
        </>
      ) : null}

      {item.slug === "untis" ? (
        <Suspense fallback={<Loading />}>
          <UntisApp />
        </Suspense>
      ) : null}

      {item.slug === "iserv" ? (
        <Suspense fallback={<Loading />}>
          <IservApp />
        </Suspense>
      ) : null}

      {item.slug === "chess" ? (
        <Suspense fallback={<Loading />}>
          <ChessStats />
        </Suspense>
      ) : null}

      <section className="section" aria-labelledby="h-steps" data-reveal>
        <h2 className="section-title" id="h-steps">Einrichtung</h2>
        <ol className="list">
          {item.steps.map((s) => (
            <li key={s} className="row">
              <span className="row-body">
                <span className="row-title" style={{ fontSize: 14.5, color: "var(--text-2)" }}>{s}</span>
              </span>
            </li>
          ))}
        </ol>
      </section>

      {item.scopes.length > 0 ? (
        <section className="section" aria-labelledby="h-scopes" data-reveal>
          <h2 className="section-title" id="h-scopes">Benötigte Berechtigungen</h2>
          <ul className="list">
            {item.scopes.map((s) => (
              <li key={s} className="row">
                <span className="row-title" style={{ fontFamily: "var(--mono)", fontSize: 14 }}>
                  {s}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="section" aria-labelledby="h-notes" data-reveal>
        <h2 className="section-title" id="h-notes">Wichtig</h2>
        <ul className="list">
          {item.notes.map((n) => (
            <li key={n} className="row">
              <span className="row-title" style={{ fontSize: 14.5, color: "var(--text-2)" }}>{n}</span>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
