import { NextResponse } from "next/server";
import { appOrigin, exchangeCode, msConfig } from "@/lib/microsoft";
import { cookieOptions, createSession, OAUTH_COOKIE, SESSION_COOKIE } from "@/lib/session";

export const dynamic = "force-dynamic";

function cookieValue(req: Request, name: string): string | undefined {
  const header = req.headers.get("cookie") ?? "";
  for (const part of header.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === name) return rest.join("=");
  }
  return undefined;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const [savedState, verifier, nextEnc] = (cookieValue(req, OAUTH_COOKIE) ?? "").split(".");
  let next = "/integrationen/teams";
  try {
    const decoded = Buffer.from(nextEnc ?? "", "base64url").toString();
    if (/^\/integrationen\/(teams|kalender|dateien)$/.test(decoded)) next = decoded;
  } catch {
    // Standardziel verwenden
  }

  const back = (code: string) => {
    const res = NextResponse.redirect(new URL(`${next}?fehler=${code}`, appOrigin(req)));
    res.cookies.set(OAUTH_COOKIE, "", { ...cookieOptions(req, 0) });
    return res;
  };

  const config = msConfig();
  if (!config) return back("nicht-eingerichtet");
  if (url.searchParams.get("error")) return back("abgebrochen");

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  if (!code || !state || !savedState || !verifier || state !== savedState) return back("ungueltig");

  const tokens = await exchangeCode(config, code, verifier);
  if (!tokens) return back("token");

  // Anzeigename für die Sitzung (nicht kritisch, wenn er fehlt).
  let name: string | null = null;
  let userId: string | null = null;
  try {
    const me = await fetch("https://graph.microsoft.com/v1.0/me?$select=id,displayName", {
      headers: { Authorization: `Bearer ${tokens.accessToken}` },
      signal: AbortSignal.timeout(8000),
      cache: "no-store",
    });
    if (me.ok) {
      const j = (await me.json()) as { id?: string; displayName?: string };
      name = j.displayName ?? null;
      userId = j.id ?? null;
    }
  } catch {
    // ignorieren
  }

  const sid = createSession({ ...tokens, name, userId });
  if (!sid) return back("nicht-eingerichtet");

  const res = NextResponse.redirect(new URL(next, appOrigin(req)));
  res.cookies.set(SESSION_COOKIE, sid, cookieOptions(req, 8 * 60 * 60));
  res.cookies.set(OAUTH_COOKIE, "", { ...cookieOptions(req, 0) });
  return res;
}
