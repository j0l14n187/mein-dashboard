import { NextResponse } from "next/server";
import { appOrigin } from "@/lib/microsoft";
import { cookieOptions, deleteSessionByCookie, SESSION_COOKIE } from "@/lib/session";

export const dynamic = "force-dynamic";

// POST, damit Abmelden nicht durch einen bloßen Link von fremden Seiten ausgelöst werden kann.
export async function POST(req: Request) {
  const header = req.headers.get("cookie") ?? "";
  const match = header.split(";").map((p) => p.trim()).find((p) => p.startsWith(`${SESSION_COOKIE}=`));
  deleteSessionByCookie(match?.slice(SESSION_COOKIE.length + 1));

  const res = NextResponse.redirect(new URL("/integrationen", appOrigin(req)), 303);
  res.cookies.set(SESSION_COOKIE, "", cookieOptions(req, 0));
  return res;
}
