import { createHash, randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { appOrigin, buildAuthUrl, msConfig } from "@/lib/microsoft";
import { cookieOptions, OAUTH_COOKIE } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const config = msConfig();
  if (!config) {
    return NextResponse.redirect(new URL("/integrationen/teams?fehler=nicht-eingerichtet", appOrigin(req)));
  }

  const nextRaw = new URL(req.url).searchParams.get("next") ?? "";
  const next = /^\/integrationen\/(teams|kalender|dateien)$/.test(nextRaw) ? nextRaw : "/integrationen/teams";

  const state = randomBytes(24).toString("base64url");
  const verifier = randomBytes(48).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");

  const res = NextResponse.redirect(buildAuthUrl(config, state, challenge));
  res.cookies.set(OAUTH_COOKIE, `${state}.${verifier}.${Buffer.from(next).toString("base64url")}`, cookieOptions(req, 600));
  return res;
}
