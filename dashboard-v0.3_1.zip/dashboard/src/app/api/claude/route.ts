import { NextResponse, type NextRequest } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_MESSAGES = 20;
const MAX_CHARS = 4000;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 20;

const SYSTEM_PROMPT =
  "Du bist Claude, ein hilfreicher Assistent in einem persönlichen Dashboard für den Schulalltag. " +
  "Antworte auf Deutsch, klar und knapp. Hilf beim Lernen, Planen und bei Alltagsfragen.";

// Einfaches Limit pro IP im Arbeitsspeicher (schützt vor versehentlich hohen Kosten).
const hits = new Map<string, number[]>();

function rateLimited(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS_PER_WINDOW) {
    hits.set(ip, recent);
    return true;
  }
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 500) {
    for (const [key, times] of hits) {
      if (times.every((t) => now - t >= WINDOW_MS)) hits.delete(key);
    }
  }
  return false;
}

function fail(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

type ChatMessage = { role: "user" | "assistant"; content: string };

function parseMessages(body: unknown): ChatMessage[] | null {
  const raw = (body as { messages?: unknown } | null)?.messages;
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_MESSAGES) return null;

  const messages: ChatMessage[] = [];
  for (const m of raw) {
    if (typeof m !== "object" || m === null) return null;
    const { role, content } = m as { role?: unknown; content?: unknown };
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") return null;
    const text = content.trim();
    if (!text || text.length > MAX_CHARS) return null;
    messages.push({ role, content: text });
  }
  if (messages[0].role !== "user" || messages[messages.length - 1].role !== "user") return null;
  return messages;
}

export async function POST(req: NextRequest) {
  const apiKey = process.env.ANTHROPIC_API_KEY?.trim();
  if (!apiKey) {
    return fail("Claude ist noch nicht eingerichtet. Es fehlt der API-Schlüssel.", 503);
  }

  // Nur Anfragen von dieser Seite selbst erlauben.
  const origin = req.headers.get("origin");
  if (origin) {
    let originHost = "";
    try {
      originHost = new URL(origin).host;
    } catch {
      return fail("Ungültige Anfrage.", 403);
    }
    const allowed = [req.headers.get("host"), req.headers.get("x-forwarded-host")].filter(Boolean);
    if (!allowed.includes(originHost)) return fail("Ungültige Anfrage.", 403);
  }

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "lokal";
  if (rateLimited(ip)) {
    return fail("Zu viele Anfragen. Bitte warte ein paar Minuten.", 429);
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return fail("Ungültige Anfrage.", 400);
  }

  const messages = parseMessages(body);
  if (!messages) return fail("Ungültige oder zu lange Nachricht.", 400);

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.CLAUDE_MODEL?.trim() || "claude-sonnet-5-5",
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages,
      }),
      signal: AbortSignal.timeout(60_000),
    });

    if (!res.ok) {
      console.error("Claude-API-Fehler, Status:", res.status);
      if (res.status === 401 || res.status === 403) {
        return fail("Der API-Schlüssel wurde abgelehnt. Prüfe ihn in .env.local.", 502);
      }
      if (res.status === 429) return fail("Claude ist gerade ausgelastet. Versuche es gleich noch einmal.", 502);
      return fail("Claude konnte gerade nicht antworten.", 502);
    }

    const data = (await res.json()) as { content?: { type?: string; text?: string }[] };
    const reply = (data.content ?? [])
      .filter((b) => b.type === "text" && typeof b.text === "string")
      .map((b) => b.text)
      .join("\n")
      .trim();

    if (!reply) return fail("Claude hat keine Antwort geliefert.", 502);
    return NextResponse.json({ reply });
  } catch (err) {
    console.error("Claude-Anfrage fehlgeschlagen:", err instanceof Error ? err.name : "unbekannt");
    return fail("Claude ist gerade nicht erreichbar.", 502);
  }
}
