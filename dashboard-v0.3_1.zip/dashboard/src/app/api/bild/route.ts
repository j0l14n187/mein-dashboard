// Bild-Proxy: Der Server holt Nachrichtenbilder von tagesschau.de und liefert sie von der eigenen Adresse aus.
// So bleibt die Content-Security-Policy streng (img-src 'self') und dein Browser kontaktiert keine Fremdserver.

import { isAllowedImageUrl } from "@/lib/tagesschau";

export const runtime = "nodejs";

const MAX_BYTES = 3_000_000;

export async function GET(req: Request) {
  const raw = new URL(req.url).searchParams.get("u");
  if (!raw || raw.length > 600 || !isAllowedImageUrl(raw)) {
    return new Response("Ungültige Bildadresse.", { status: 400 });
  }

  try {
    const upstream = await fetch(raw, {
      redirect: "error", // keine Weiterleitungen auf andere Hosts
      signal: AbortSignal.timeout(8000),
      next: { revalidate: 86_400 },
      headers: { Accept: "image/avif,image/webp,image/jpeg,image/png,image/*;q=0.8" },
    });
    const type = upstream.headers.get("content-type") ?? "";
    if (!upstream.ok || !/^image\/(jpeg|png|webp|avif|gif)/i.test(type)) {
      return new Response("Bild nicht verfügbar.", { status: 502 });
    }
    const buf = await upstream.arrayBuffer();
    if (buf.byteLength > MAX_BYTES) return new Response("Bild zu groß.", { status: 502 });

    return new Response(buf, {
      headers: {
        "Content-Type": type.split(";")[0],
        "Cache-Control": "public, max-age=86400, stale-while-revalidate=604800",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return new Response("Bild nicht verfügbar.", { status: 502 });
  }
}
