import type { Metadata } from "next";
import { legal } from "@/lib/legal";

export const metadata: Metadata = { title: "Impressum" };

export default function ImpressumPage() {
  return (
    <>
      <h1 className="large-title">Impressum</h1>
      <p className="lede">Angaben gemäß § 5 DDG</p>

      <div className="prose">
        <h2>Anbieter</h2>
        <address>
          {legal.name}
          <br />
          {legal.street}
          <br />
          {legal.city}
          <br />
          {legal.country}
        </address>

        <h2>Kontakt</h2>
        <p>
          E-Mail: {legal.email}
          <br />
          Telefon: {legal.phone}
        </p>

        <h2>Haftung für Inhalte</h2>
        <p>
          Die Inhalte dieser Seite werden mit Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit
          und Aktualität kann jedoch keine Gewähr übernommen werden. Die Seite befindet sich in
          Entwicklung (Version 0.1). Beispieldaten sind als solche gekennzeichnet.
        </p>

        <h2>Haftung für Links</h2>
        <p>
          Diese Seite kann Links zu externen Webseiten Dritter enthalten, auf deren Inhalte kein
          Einfluss besteht. Für diese fremden Inhalte ist stets der jeweilige Anbieter verantwortlich.
          Bei Bekanntwerden von Rechtsverletzungen werden entsprechende Links umgehend entfernt.
        </p>

        <h2>Urheberrecht</h2>
        <p>
          Die auf dieser Seite erstellten Inhalte und Werke unterliegen dem deutschen Urheberrecht.
          Beiträge Dritter sind als solche gekennzeichnet. Eine Vervielfältigung oder Verwertung
          außerhalb der Grenzen des Urheberrechts bedarf der Zustimmung des jeweiligen Urhebers.
        </p>

        <h2>Marken und Unabhängigkeit</h2>
        <p>
          Microsoft, Microsoft Teams und Microsoft 365 sind Marken der Microsoft-Unternehmensgruppe.
          WebUntis und Untis sind Marken der Untis GmbH. IServ ist eine Marke der IServ GmbH.
          Chess.com ist eine Marke von Chess.com, LLC. Claude ist eine Marke von Anthropic, PBC.
          Tagesschau ist eine Marke der ARD. Dieses Projekt ist unabhängig und steht in keiner
          Verbindung zu den genannten Unternehmen. Es wird weder von ihnen unterstützt noch
          empfohlen.
        </p>

        <h2>Verbraucherstreitbeilegung</h2>
        <p>
          Ich bin weder bereit noch verpflichtet, an Streitbeilegungsverfahren vor einer
          Verbraucherschlichtungsstelle teilzunehmen.
        </p>
      </div>
    </>
  );
}
