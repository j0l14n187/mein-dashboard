import type { CSSProperties } from "react";
import Link from "next/link";
import { Suspense } from "react";
import { CardSkeleton, EventsCard, TimetableCard, TopNewsCard, WeatherCard } from "@/components/HomeCards";
import { Icon } from "@/components/Icon";
import { getStatuses } from "@/lib/integration-status";
import { integrations } from "@/lib/integrations";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const statuses = await getStatuses();
  const today = new Date().toLocaleDateString("de-DE", {
    timeZone: "Europe/Berlin",
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  return (
    <>
      <div>
        <p className="eyebrow">{today}</p>
        <h1 className="large-title">Übersicht</h1>
        <p className="lede">Dein Tag auf einen Blick.</p>
      </div>

      <div className="bento">
        <div className="span-7">
          <Suspense fallback={<CardSkeleton />}>
            <TimetableCard />
          </Suspense>
        </div>
        <div className="span-5">
          <Suspense fallback={<CardSkeleton />}>
            <WeatherCard />
          </Suspense>
        </div>
        <div className="span-7" data-reveal>
          <Suspense fallback={<CardSkeleton tall />}>
            <TopNewsCard />
          </Suspense>
        </div>
        <div className="span-5" data-reveal style={{ "--i": 1 } as CSSProperties}>
          <Suspense fallback={<CardSkeleton tall />}>
            <EventsCard />
          </Suspense>
        </div>
      </div>

      <section className="section" aria-labelledby="h-int" data-reveal>
        <h2 className="section-title" id="h-int">Apps</h2>
        <div className="tiles">
          {integrations.map((i) => {
            const status = statuses[i.slug];
            return (
              <Link
                key={i.slug}
                href={`/integrationen/${i.slug}`}
                className="card tile glow"
              >
                <span className="row-icon" style={{ "--c": i.color } as CSSProperties}>
                  <Icon name={i.icon} size={18} />
                </span>
                <span className="row-body">
                  <span className="row-title">{i.title}</span>
                  <span className="row-sub">{i.subtitle}</span>
                </span>
                <span className="tile-foot">
                  <span className={`badge ${status?.connected ? "on" : "off"}`}>{status?.label}</span>
                  <Icon name="chevron" size={16} />
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="section" aria-labelledby="h-next" data-reveal>
        <h2 className="section-title" id="h-next">Aufgaben</h2>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <Link href="/aufgaben" className="btn secondary">
            Aufgabenliste öffnen
          </Link>
        </div>
      </section>
    </>
  );
}
