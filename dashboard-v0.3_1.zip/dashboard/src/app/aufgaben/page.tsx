import type { Metadata } from "next";
import { TaskDemo } from "@/components/TaskDemo";

export const metadata: Metadata = { title: "Aufgaben" };

export default function AufgabenPage() {
  return (
    <>
      <div>
        <p className="eyebrow">Lokal gespeichert</p>
        <h1 className="large-title">Aufgaben</h1>
        <p className="lede">Halte fest, was als Nächstes ansteht.</p>
      </div>
      <TaskDemo />
    </>
  );
}
