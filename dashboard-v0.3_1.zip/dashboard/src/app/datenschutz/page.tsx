import type { Metadata } from "next";
import { legal } from "@/lib/legal";

export const metadata: Metadata = { title: "Datenschutz" };

export default function DatenschutzPage() {
  return (
    <>
      <h1 className="large-title">Datenschutz</h1>
      <p className="lede">Informationen nach Art. 13 DSGVO. Stand: {legal.updated}.</p>

      <div className="prose">
        <h2>1. Verantwortliche Stelle</h2>
        <address>
          {legal.name}
          <br />
          {legal.street}, {legal.city}
          <br />
          E-Mail: {legal.email}
        </address>

        <h2>2. Kurzüberblick</h2>
        <ul>
          <li>
            Es gibt keine Registrierung, keine Werbung und keine Analyse- oder Tracking-Dienste. Ein Cookie wird
            nur gesetzt, wenn du dich mit Microsoft anmeldest (technisch notwendiges Sitzungs-Cookie, siehe
            Abschnitt 4).
          </li>
          <li>Dein Browser lädt keine Schriften, Skripte oder Bilder von fremden Servern.</li>
          <li>
            Wetter, Nachrichten (samt Bildern) und Schach-Statistiken ruft der Server ab, nicht dein Browser. Die
            Nachrichtenbilder liefert das Dashboard selbst aus. Deine IP-Adresse wird dabei nicht an diese Dienste
            übermittelt.
          </li>
          <li>Aufgaben, die du eingibst, bleiben in deinem Browser.</li>
          <li>
            Nur wenn du den optionalen Claude-Chat nutzt, werden deine Nachrichten an Anthropic gesendet (siehe
            Abschnitt 6).
          </li>
          <li>
            Teams, Kalender, Dateien, WebUntis und IServ sind nur aktiv, wenn der Betreiber sie eingerichtet hat
            (siehe Abschnitt 7).
          </li>
        </ul>

        <h2>3. Hosting und Server-Logfiles</h2>
        <p>
          Beim Aufruf dieser Seite verarbeitet der Server technisch notwendige Daten: IP-Adresse, Datum und
          Uhrzeit, aufgerufene Seite, übertragene Datenmenge, Statuscode sowie Browser- und
          Betriebssysteminformationen (User-Agent). Dies ist nötig, um die Seite auszuliefern und ihre Sicherheit
          zu gewährleisten.
        </p>
        <p>
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse am sicheren und stabilen
          Betrieb). Die Daten werden nicht mit anderen Daten zusammengeführt.
        </p>
        <p>
          Hosting-Anbieter: {legal.hostName}
          <br />
          Speicherdauer der Logs: {legal.logRetention}
        </p>

        <h2>4. Speicherung im Browser</h2>
        <p>
          Die Aufgabenliste wird im lokalen Speicher deines Browsers (localStorage) abgelegt, damit sie beim
          nächsten Besuch noch da ist. Diese Daten verlassen dein Gerät nicht. Der Zugriff ist für die von dir
          gewünschte Funktion technisch erforderlich (§ 25 Abs. 2 Nr. 2 TDDDG). Du kannst die Einträge in der App
          löschen oder die Website-Daten in den Browser-Einstellungen entfernen.
        </p>
        <p>
          Wenn du dich mit Microsoft anmeldest, setzt der Server ein Sitzungs-Cookie (<code>dashboard_sid</code>,
          httpOnly). Es enthält nur eine zufällige, signierte Kennung und gilt höchstens 8 Stunden. Es ist für die
          von dir gewünschte Anmeldung technisch erforderlich (§ 25 Abs. 2 Nr. 2 TDDDG). Beim Abmelden wird es
          gelöscht. Während der Anmeldung wird kurzzeitig ein weiteres technisches Cookie (<code>dashboard_oauth</code>)
          zur Absicherung des Ablaufs gesetzt.
        </p>

        <h2>5. Wetter, Nachrichten und Schach-Statistiken</h2>
        <p>
          Für die Seite „Aktuelles“ und die Chess.com-Statistiken fragt der Server öffentlich verfügbare Daten bei
          Drittanbietern ab und speichert sie kurz zwischen. Dabei werden keine personenbezogenen Daten der
          Besucher übermittelt. Übermittelt wird nur die IP-Adresse des Servers.
        </p>
        <ul>
          <li>Wetter für Wipperfürth: Open-Meteo.com (Daten unter CC BY 4.0).</li>
          <li>
            Schlagzeilen: tagesschau.de, mit Anreißertext und Titelbild samt Bildnachweis. Die Bilder holt der
            Server und liefert sie von dieser Seite aus (kurz zwischengespeichert). Die Artikel öffnen sich erst, wenn
            du einen Link antippst.
          </li>
          <li>
            Schach-Statistiken: Chess.com. Es werden öffentliche Daten des Kontos abgerufen, dessen Nutzername
            vom Betreiber hinterlegt wurde.
          </li>
        </ul>
        <p>
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO (Bereitstellung der Funktionen der Seite). Wenn du auf einen
          Link zu einer externen Seite tippst (zum Beispiel Tagesschau, Teams, IServ, Chess.com), verlässt du dieses
          Angebot. Dort gelten die Datenschutzhinweise des jeweiligen Anbieters.
        </p>

        <h2>6. Claude-Chat (optional)</h2>
        <p>
          Der Chat ist nur aktiv, wenn der Betreiber einen API-Schlüssel eingerichtet hat. Wenn du eine Nachricht
          sendest, überträgt der Server sie zur Beantwortung an Anthropic (API von Claude). Der Gesprächsverlauf wird
          nicht auf diesem Server gespeichert und geht verloren, sobald du die Seite verlässt.
        </p>
        <p>
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. a DSGVO: Du entscheidest selbst, ob du eine Nachricht sendest, nachdem
          dir der Hinweis unter dem Eingabefeld angezeigt wurde. Anthropic kann Daten auch in den USA verarbeiten.
          Einzelheiten stehen in den Datenschutzhinweisen von Anthropic. Gib keine Passwörter und keine Daten
          anderer Personen ein.
        </p>

        <h2>7. Optionale Verbindungen (nur wenn eingerichtet)</h2>
        <p>
          Der Betreiber kann die folgenden Verbindungen in der Datei <code>.env.local</code> einschalten. Ohne
          Einrichtung werden keine Daten abgerufen.
        </p>
        <ul>
          <li>
            <strong>Microsoft (Teams, Kalender, Dateien):</strong> Nach deiner Anmeldung ruft der Server über Microsoft
            Graph mit lesenden Rechten ab: deinen Anzeigenamen, die Liste deiner Chats und deren letzte Nachrichten
            (auch Namen und Texte anderer Personen), deine Kalendertermine und die Namen deiner zuletzt verwendeten
            OneDrive-Dateien. Die Zugriffstoken liegen nur im Arbeitsspeicher des Servers. Es werden keine Inhalte
            dauerhaft gespeichert. Microsoft kann Daten auch außerhalb der EU verarbeiten.
          </li>
          <li>
            <strong>WebUntis:</strong> Der Server ruft deinen Stundenplan über einen iCal-Link oder (falls
            eingetragen) mit den hinterlegten Zugangsdaten der WebUntis-Schnittstelle ab.
          </li>
          <li>
            <strong>IServ und Kalender-Links:</strong> Wenn ein iCal-Link eingetragen ist, ruft der Server die Termine
            von dort ab.
          </li>
          <li>
            <strong>Live-Ansicht:</strong> Erst wenn du „Live-Ansicht laden“ wählst, lädt dein Browser die Seite des
            Dienstes (zum Beispiel IServ oder WebUntis) direkt. Dabei erfährt der Dienst deine IP-Adresse, und es
            gelten dessen Datenschutzhinweise.
          </li>
        </ul>
        <p>
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. a DSGVO: Du entscheidest selbst, ob du dich anmeldest oder eine
          Live-Ansicht öffnest. Bei Daten Dritter (zum Beispiel Chatpartner) liegt die Verantwortung für die Nutzung
          beim Betreiber. Kläre vorher mit deiner Schule, ob die Nutzung erlaubt ist.
        </p>

        <h2>8. Deine Rechte</h2>
        <p>Du hast gegenüber der verantwortlichen Stelle folgende Rechte:</p>
        <ul>
          <li>Auskunft über deine gespeicherten Daten (Art. 15 DSGVO)</li>
          <li>Berichtigung unrichtiger Daten (Art. 16 DSGVO)</li>
          <li>Löschung (Art. 17 DSGVO)</li>
          <li>Einschränkung der Verarbeitung (Art. 18 DSGVO)</li>
          <li>Datenübertragbarkeit (Art. 20 DSGVO)</li>
          <li>Widerspruch gegen Verarbeitungen auf Grundlage berechtigter Interessen (Art. 21 DSGVO)</li>
          <li>Widerruf erteilter Einwilligungen mit Wirkung für die Zukunft (Art. 7 Abs. 3 DSGVO)</li>
        </ul>
        <p>
          Du hast außerdem das Recht, dich bei einer Datenschutz-Aufsichtsbehörde zu beschweren (Art. 77 DSGVO).
          Zuständig ist: {legal.authority}
        </p>

        <h2>9. Sicherheit</h2>
        <p>
          Die Seite sollte ausschließlich über eine verschlüsselte HTTPS-Verbindung bereitgestellt werden.
          Zusätzlich werden Sicherheits-Header gesetzt, die das Laden fremder Inhalte und das Einbetten in andere
          Seiten verhindern.
        </p>

        <h2>10. Änderungen</h2>
        <p>
          Diese Erklärung wird angepasst, wenn sich die Seite oder die Rechtslage ändert. Es gilt die jeweils hier
          veröffentlichte Fassung.
        </p>
      </div>
    </>
  );
}
