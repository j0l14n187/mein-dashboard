import Link from "next/link";

export default function NotFound() {
  return (
    <>
      <div>
        <p className="eyebrow">Fehler 404</p>
        <h1 className="large-title">Nicht gefunden</h1>
        <p className="lede">Diese Seite gibt es nicht.</p>
      </div>
      <div className="btn-row" style={{ marginTop: 0 }}>
        <Link href="/" className="btn">
          Zur Übersicht
        </Link>
      </div>
    </>
  );
}
