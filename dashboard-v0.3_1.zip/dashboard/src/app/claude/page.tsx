import type { Metadata } from "next";
import { ClaudeChat } from "@/components/ClaudeChat";
import { Icon } from "@/components/Icon";

export const metadata: Metadata = { title: "Claude" };
export const dynamic = "force-dynamic";

export default function ClaudePage() {
  const configured = Boolean(process.env.ANTHROPIC_API_KEY?.trim());

  return (
    <>
      <div>
        <p className="eyebrow">KI-Assistent</p>
        <h1 className="large-title">Claude</h1>
        <p className="lede">Dein KI-Assistent direkt im Dashboard.</p>
      </div>

      <ClaudeChat configured={configured} />

      {/* Der Chat läuft im Dashboard. Der Link zu claude.ai ist nur der Ersatz, solange kein Schlüssel eingetragen ist. */}
      {!configured ? (
        <div className="btn-row">
          <a href="https://claude.ai" className="btn secondary" target="_blank" rel="noopener noreferrer">
            Claude.ai öffnen
            <Icon name="external" size={18} />
          </a>
        </div>
      ) : null}

      {!configured ? (
        <section className="section" aria-labelledby="h-setup">
          <h2 className="section-title" id="h-setup">Chat einrichten</h2>
          <ol className="list">
            <li className="row">
              <span className="row-title" style={{ fontSize: 15 }}>
                In der Anthropic Console (console.anthropic.com) ein Konto anlegen und einen API-Schlüssel erstellen.
              </span>
            </li>
            <li className="row">
              <span className="row-title" style={{ fontSize: 15 }}>
                In der Datei .env.local eine Zeile ANTHROPIC_API_KEY=dein-schlüssel einfügen.
              </span>
            </li>
            <li className="row">
              <span className="row-title" style={{ fontSize: 15 }}>
                Das Dashboard neu starten (Strg + C, dann npm run dev).
              </span>
            </li>
          </ol>
          <p className="footnote">
            Die API wird nach Verbrauch abgerechnet und ist getrennt von einem Claude.ai-Abo. Veröffentliche den
            Schlüssel nie und teile ihn mit niemandem. Ohne Schlüssel kannst du Claude über den Knopf oben direkt auf
            claude.ai nutzen.
          </p>
        </section>
      ) : null}
    </>
  );
}
