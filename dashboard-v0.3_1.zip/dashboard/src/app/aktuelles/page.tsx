import type { Metadata } from "next";
import type { CSSProperties } from "react";
import { NewsCard, NewsHero, NewsRow, SourceNote } from "@/components/NewsCards";
import { WeatherIcon } from "@/components/WeatherIcon";
import { getNews } from "@/lib/tagesschau";
import { describeWeather, getWeather, weatherKind } from "@/lib/weather";

export const metadata: Metadata = { title: "Aktuelles" };
export const revalidate = 300;

function dayLabel(date: string, index: number) {
  if (index === 0) return "Heute";
  const d = new Date(`${date}T12:00:00`);
  return Number.isNaN(d.getTime()) ? date : d.toLocaleDateString("de-DE", { weekday: "short" });
}

export default async function AktuellesPage() {
  const [weather, news] = await Promise.all([getWeather(), getNews(14)]);

  const hero = news?.[0] ?? null;
  const cards = news?.slice(1, 5) ?? [];
  const rows = news?.slice(5) ?? [];

  return (
    <>
      <div>
        <p className="eyebrow">Live</p>
        <h1 className="large-title">Aktuelles</h1>
        <p className="lede">Wetter und Nachrichten, alle paar Minuten aktualisiert.</p>
      </div>

      <section className="section" aria-labelledby="h-wetter">
        <h2 className="section-title" id="h-wetter">Wetter in Wipperfürth</h2>
        {weather ? (
          <>
            <div className="panel weather-now glow">
              <WeatherIcon kind={weatherKind(weather.code)} />
              <span className="temp">{Math.round(weather.temperature)}°</span>
              <span className="row-body">
                <span className="row-title">{describeWeather(weather.code)}</span>
                <span className="row-sub">
                  {weather.feelsLike !== null ? `Gefühlt ${Math.round(weather.feelsLike)}°` : ""}
                  {weather.feelsLike !== null && weather.wind !== null ? " · " : ""}
                  {weather.wind !== null ? `Wind ${Math.round(weather.wind)} km/h` : ""}
                  {weather.humidity !== null ? ` · Luftfeuchte ${Math.round(weather.humidity)} %` : ""}
                </span>
              </span>
            </div>

            {weather.days.length > 0 ? (
              <div className="forecast">
                {weather.days.map((d, i) => (
                  <div key={d.date} className="panel fc glow" data-reveal style={{ "--i": i } as CSSProperties}>
                    <span className="fc-day">{dayLabel(d.date, i)}</span>
                    <WeatherIcon kind={weatherKind(d.code)} small />
                    <span className="fc-temp">
                      {Math.round(d.max)}° <span>/ {Math.round(d.min)}°</span>
                    </span>
                    <span className="row-sub">
                      {describeWeather(d.code)}
                      {d.rainChance !== null ? ` · ${Math.round(d.rainChance)} % Regen` : ""}
                    </span>
                  </div>
                ))}
              </div>
            ) : null}
          </>
        ) : (
          <p className="notice">Das Wetter ist gerade nicht verfügbar. Versuche es später noch einmal.</p>
        )}
        <p className="footnote">
          Wetterdaten von{" "}
          <a href="https://open-meteo.com/" target="_blank" rel="noopener noreferrer">
            Open-Meteo.com
          </a>{" "}
          (Lizenz CC BY 4.0).
        </p>
      </section>

      <section className="section" aria-labelledby="h-news">
        <h2 className="section-title" id="h-news">Schlagzeilen</h2>
        {hero ? (
          <>
            <NewsHero item={hero} />

            {cards.length > 0 ? (
              <div className="news-grid">
                {cards.map((n, i) => (
                  <NewsCard key={n.id} item={n} index={i % 2} />
                ))}
              </div>
            ) : null}

            {rows.length > 0 ? (
              <div className="news-rows">
                {rows.map((n, i) => (
                  <NewsRow key={n.id} item={n} index={i % 3} />
                ))}
              </div>
            ) : null}
          </>
        ) : (
          <p className="notice">
            Die Schlagzeilen sind gerade nicht verfügbar. Du kannst die Nachrichten direkt auf{" "}
            <a href="https://www.tagesschau.de/" target="_blank" rel="noopener noreferrer">
              tagesschau.de
            </a>{" "}
            lesen.
          </p>
        )}
        <SourceNote />
      </section>
    </>
  );
}
