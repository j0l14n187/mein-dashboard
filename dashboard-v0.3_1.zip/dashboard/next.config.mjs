const isDev = process.env.NODE_ENV !== "production";

// Nur diese Seiten dürfen als Live-Ansicht eingebettet werden (aus .env.local, nur https).
function originOf(raw) {
  try {
    const url = new URL(String(raw ?? "").trim());
    return url.protocol === "https:" ? url.origin : null;
  } catch {
    return null;
  }
}
const untisServer = process.env.UNTIS_SERVER?.trim().replace(/^https?:\/\//i, "").replace(/\/.*$/, "");
const frameOrigins = [
  originOf(process.env.ISERV_URL),
  originOf(process.env.UNTIS_URL),
  untisServer ? originOf(`https://${untisServer}`) : null,
].filter(Boolean);

// Strenge Content-Security-Policy: keine externen Skripte, Schriften, Bilder oder Tracker.
// Rahmen (frame-src) sind nur für die in .env.local eingetragenen Schul-Seiten erlaubt.
// 'unsafe-inline' für Skripte/Styles ist für Next.js ohne Nonce-Setup nötig;
// 'unsafe-eval' wird nur im Entwicklungsmodus erlaubt.
const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  `frame-src ${["'self'", ...new Set(frameOrigins)].join(" ")}`,
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join("; ");

const securityHeaders = [
  { key: "Content-Security-Policy", value: csp },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  {
    key: "Permissions-Policy",
    value: "camera=(), microphone=(), geolocation=(), payment=(), interest-cohort=()",
  },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
  { key: "X-Robots-Tag", value: "noindex, nofollow" },
];

/** @type {import('next').NextConfig} */
const nextConfig = {
  poweredByHeader: false,
  // Blendet die englische Entwickler-Schaltfläche („N“) unten links aus.
  devIndicators: false,
  reactStrictMode: true,
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

export default nextConfig;
