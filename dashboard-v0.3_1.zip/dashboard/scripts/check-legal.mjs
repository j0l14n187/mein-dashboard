// Prüft, ob in src/lib/legal.ts noch Platzhalter stehen.
// Aufruf: npm run check:legal
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const file = join(root, "src", "lib", "legal.ts");
const lines = readFileSync(file, "utf8").split("\n");

const open = [];
lines.forEach((line, i) => {
  if (/^\s*\w+:\s*".*\[PLATZHALTER/.test(line)) open.push(`  Zeile ${i + 1}: ${line.trim()}`);
});

if (open.length > 0) {
  console.error(`Noch ${open.length} Platzhalter in src/lib/legal.ts:\n${open.join("\n")}`);
  console.error("\nFülle diese Angaben aus, bevor die Seite öffentlich online geht.");
  process.exit(1);
}

console.log("Alle rechtlichen Angaben sind ausgefüllt.");
