# Dashboard (Version 0.3)

Persönliches Dashboard mit Übersicht, Aktuelles (Wetter und Tagesschau), Aufgaben, Claude-Chat und Integrationen (Teams, WebUntis, IServ, Kalender, Dateien, Chess.com). Futuristisches, minimales Design.

## Lokal starten

Voraussetzung: Node.js 20.9 oder neuer.

```bash
cd dashboard
npm install
npm run dev
```

Dann im Browser http://localhost:3000 öffnen. Typen prüfen: `npm run typecheck`

## Update von Version 0.2 auf 0.3

ZIP in den Ordner daneben legen und im Terminal ausführen:

```bash
unzip -o dashboard-v0.3.zip -x "dashboard/src/lib/legal.ts"
cd dashboard
npm run dev
```

`-o` überschreibt die geänderten Dateien. `node_modules`, `.env.local` und deine Angaben in `src/lib/legal.ts` bleiben unberührt (`-x` schließt diese Datei aus).

## Einstellungen in .env.local

Kopiere `.env.example` zu `.env.local` und fülle nur aus, was du nutzen willst. Danach das Dashboard neu starten.

| Variable | Wofür |
| --- | --- |
| `CHESSCOM_USERNAME` | Zeigt die öffentlichen Chess.com-Statistiken dieses Kontos |
| `ISERV_URL` | Adresse deiner IServ-Seite (https), für den Knopf „IServ öffnen“ |
| `ANTHROPIC_API_KEY` | Schaltet den Claude-Chat frei. Die API wird nach Verbrauch abgerechnet. |

## Wo du was änderst

| Was | Datei |
| --- | --- |
| Startseite | `src/app/page.tsx` |
| Wetter und Nachrichten | `src/app/aktuelles/page.tsx`, `src/lib/weather.ts`, `src/lib/tagesschau.ts` |
| Claude-Chat | `src/components/ClaudeChat.tsx`, `src/app/api/claude/route.ts` |
| Chess.com | `src/lib/chess.ts`, `src/components/ChessStats.tsx` |
| Integrationen (Texte, Reihenfolge) | `src/lib/integrations.ts` |
| Navigation und Seitenleiste | `src/components/Shell.tsx` |
| Farben, Abstände, Schrift | `src/app/globals.css` |
| Impressum und Datenschutz (deine Angaben) | `src/lib/legal.ts` |
| Sicherheits-Header | `next.config.mjs` |

## Rechtliches: vor dem Veröffentlichen

Das ist keine Rechtsberatung. Die Texte sind eine sorgfältige Grundlage für ein privates Projekt, aber keine Garantie.

1. **Platzhalter ausfüllen.** Trage in `src/lib/legal.ts` deinen Namen, deine ladungsfähige Anschrift, E-Mail, Hoster, Log-Speicherdauer und die zuständige Datenschutzbehörde ein. Prüfen mit `npm run check:legal`.
2. **Nur lokal oder im privaten Codespace?** Dann ist niemand sonst erreichbar und ein Impressum nicht nötig. Sobald die Seite öffentlich im Internet steht, brauchst du Impressum und Datenschutzerklärung.
3. **Claude-Chat nie öffentlich.** Der Chat hat keine Anmeldung. Wer die Seite erreicht, könnte auf deine Kosten chatten. Ein einfaches Limit pro IP ist eingebaut, ersetzt aber keinen Schutz. Nutze den Chat nur lokal oder im privaten Codespace, oder baue vorher eine Anmeldung ein. Nachrichten gehen an Anthropic (USA).
4. **Nachrichten und Wetter.** Die Tagesschau-Schnittstelle ist nicht offiziell dokumentiert und ihre Nutzungsbedingungen konnte ich nicht prüfen. Lies sie nach, bevor du die Seite öffentlich machst. Verwendet werden nur Überschriften und Links mit Quellenangabe. Open-Meteo ist für nicht-kommerzielle Nutzung frei und verlangt die Quellenangabe (ist eingebaut).
5. **Anschrift beachten.** Ein Impressum zeigt deine Privatadresse öffentlich. Wenn du das nicht willst, veröffentliche die Seite nicht öffentlich.
6. **Schulkonto und Daten Dritter.** Teams-Chats und Stundenpläne enthalten Daten anderer Personen. Frage deine Schule, ob du ein Schulkonto mit einer eigenen App verbinden darfst.
7. **Vor jeder neuen Integration** die Datenschutzerklärung (`src/app/datenschutz/page.tsx`) erweitern.
8. **Unter 18?** Sprich vor einer Veröffentlichung mit deinen Eltern.

## Was bereits eingebaut ist

- Keine Cookies, kein Tracking, keine Analyse-Dienste, keine Werbung
- Keine Schriften, Skripte oder Bilder von fremden Servern. Alle externen Daten holt der Server, nicht dein Browser.
- Strenge Content-Security-Policy und weitere Sicherheits-Header
- `noindex` und `robots.txt`
- Impressum nach § 5 DDG und Datenschutzerklärung nach Art. 13 DSGVO, in der Fußzeile jeder Seite
- Quellenangaben für Open-Meteo, Tagesschau und Chess.com
- Aufgaben liegen nur im Browser (localStorage)
- Barrierefreiheit: Tastaturbedienung, Fokusanzeige, Beschriftungen, Hell- und Dunkelmodus, reduzierte Bewegung

## Teams, WebUntis und Co. verbinden

Diese Dienste lassen sich nicht einfach einbetten, sie müssen sich per Anmeldung (OAuth) mit dem Dashboard verbinden. Bis dahin öffnen die Knöpfe auf den Integrationsseiten den Dienst in einem neuen Tab.

1. Im Microsoft Entra Admin Center unter „App-Registrierungen“ eine neue Registrierung anlegen.
2. Redirect-URL: `http://localhost:3000/api/auth/microsoft/callback` (im Codespace die Adresse des Codespace verwenden).
3. Zunächst nur delegierte Berechtigungen `User.Read`, `Chat.ReadBasic`, `Chat.Read` anfragen. Ob du sie freigeben darfst, entscheidet die IT deiner Schule.
4. Kein Client-Secret im Frontend. Die Anmeldung wird serverseitig gebaut. Werte kommen in `.env.local`.
